
'use client';

import { useState } from 'react';
import Navigation from '@/components/navigation';
import FormPage from '@/components/form-page';
import ProgressPage from '@/components/progress-page';
import DashboardPage from '@/components/dashboard-page';

export default function Home() {
  const [activeTab, setActiveTab] = useState<'form' | 'progress' | 'dashboard'>('form');

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'form':
        return <FormPage />;
      case 'progress':
        return <ProgressPage />;
      case 'dashboard':
        return <DashboardPage />;
      default:
        return <FormPage />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderActiveTab()}
      </main>
    </div>
  );
}
