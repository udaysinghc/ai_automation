
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Weight, Plus, TrendingUp, TrendingDown } from 'lucide-react';
import { saveWeight, getWeightTrend } from '@/lib/storage';
import { toast } from 'sonner';

export default function WeightForm() {
  const [formData, setFormData] = useState({
    weight: '',
    date: new Date().toISOString().split('T')[0],
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.weight) {
      toast.error('Please enter your weight');
      return;
    }

    setIsSubmitting(true);

    try {
      saveWeight({
        date: formData.date,
        weight: parseFloat(formData.weight),
      });

      toast.success('Weight logged successfully!');
      
      // Reset form
      setFormData({
        weight: '',
        date: new Date().toISOString().split('T')[0],
      });
    } catch (error) {
      toast.error('Failed to log weight. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const weightTrend = getWeightTrend();

  return (
    <Card className="border-primary/20">
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="weight-date" className="text-sm font-medium">
                Date
              </Label>
              <Input
                id="weight-date"
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="border-primary/30 focus:border-primary"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="weight-value" className="text-sm font-medium">
                Weight (lbs)
              </Label>
              <div className="relative">
                <Weight className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary w-4 h-4" />
                <Input
                  id="weight-value"
                  type="number"
                  step="0.1"
                  min="0"
                  placeholder="0.0"
                  value={formData.weight}
                  onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                  className="pl-10 border-primary/30 focus:border-primary"
                />
              </div>
            </div>
          </div>

          {weightTrend.current && (
            <div className="bg-muted/50 p-4 rounded-lg">
              <h3 className="font-medium text-sm mb-2 flex items-center">
                <Weight className="w-4 h-4 mr-2 text-primary" />
                Weight Trend
              </h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Current:</span>
                  <span className="font-medium">{weightTrend.current} lbs</span>
                </div>
                {weightTrend.change !== null && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Change:</span>
                    <div className="flex items-center">
                      {weightTrend.change > 0 ? (
                        <TrendingUp className="w-4 h-4 mr-1 text-red-500" />
                      ) : weightTrend.change < 0 ? (
                        <TrendingDown className="w-4 h-4 mr-1 text-green-500" />
                      ) : null}
                      <span className={`font-medium ${
                        weightTrend.change > 0 ? 'text-red-500' : 
                        weightTrend.change < 0 ? 'text-green-500' : 
                        'text-muted-foreground'
                      }`}>
                        {weightTrend.change > 0 ? '+' : ''}{weightTrend.change?.toFixed(1)} lbs
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <Button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium py-3 rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Logging Weight...
              </>
            ) : (
              <>
                <Plus className="w-4 h-4 mr-2" />
                Log Weight
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
