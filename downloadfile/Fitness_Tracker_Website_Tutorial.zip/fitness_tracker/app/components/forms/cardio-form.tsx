
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Heart, Clock, Flame, Plus } from 'lucide-react';
import { CARDIO_TYPES } from '@/lib/types';
import { saveCardio } from '@/lib/storage';
import { toast } from 'sonner';

export default function CardioForm() {
  const [formData, setFormData] = useState({
    cardioType: '',
    duration: '',
    caloriesBurned: '',
    date: new Date().toISOString().split('T')[0],
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.cardioType || !formData.duration || !formData.caloriesBurned) {
      toast.error('Please fill in all fields');
      return;
    }

    setIsSubmitting(true);

    try {
      saveCardio({
        date: formData.date,
        cardioType: formData.cardioType,
        duration: parseFloat(formData.duration),
        caloriesBurned: parseInt(formData.caloriesBurned),
      });

      toast.success('Cardio session logged successfully!');
      
      // Reset form
      setFormData({
        cardioType: '',
        duration: '',
        caloriesBurned: '',
        date: new Date().toISOString().split('T')[0],
      });
    } catch (error) {
      toast.error('Failed to log cardio session. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="border-primary/20">
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="cardio-date" className="text-sm font-medium">
                Date
              </Label>
              <Input
                id="cardio-date"
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="border-primary/30 focus:border-primary"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cardio-type" className="text-sm font-medium">
                Cardio Type
              </Label>
              <Select
                value={formData.cardioType}
                onValueChange={(value) => setFormData({ ...formData, cardioType: value })}
              >
                <SelectTrigger className="border-primary/30 focus:border-primary">
                  <SelectValue placeholder="Select cardio type" />
                </SelectTrigger>
                <SelectContent>
                  {CARDIO_TYPES.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="duration" className="text-sm font-medium">
                Duration (minutes)
              </Label>
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary w-4 h-4" />
                <Input
                  id="duration"
                  type="number"
                  step="0.1"
                  min="0"
                  placeholder="0"
                  value={formData.duration}
                  onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                  className="pl-10 border-primary/30 focus:border-primary"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="calories-burned" className="text-sm font-medium">
                Calories Burned
              </Label>
              <div className="relative">
                <Flame className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary w-4 h-4" />
                <Input
                  id="calories-burned"
                  type="number"
                  min="0"
                  placeholder="0"
                  value={formData.caloriesBurned}
                  onChange={(e) => setFormData({ ...formData, caloriesBurned: e.target.value })}
                  className="pl-10 border-primary/30 focus:border-primary"
                />
              </div>
            </div>
          </div>

          <Button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium py-3 rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Logging Cardio...
              </>
            ) : (
              <>
                <Plus className="w-4 h-4 mr-2" />
                Log Cardio Session
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
