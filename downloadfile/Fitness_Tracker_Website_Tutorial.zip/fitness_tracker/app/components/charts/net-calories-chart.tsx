
'use client';

import { Area, AreaChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, ReferenceLine } from 'recharts';
import { DailyData } from '@/lib/types';
import { getTotalCaloriesForDate } from '@/lib/storage';

interface NetCaloriesChartProps {
  data: DailyData[];
}

export default function NetCaloriesChart({ data }: NetCaloriesChartProps) {
  const chartData = data
    .map(day => {
      const calories = getTotalCaloriesForDate(day.date);
      return {
        date: day.date,
        net: calories.net,
        formattedDate: new Date(day.date).toLocaleDateString('en-US', { 
          month: 'short', 
          day: 'numeric' 
        })
      };
    })
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  if (chartData.length === 0) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground">
        No net calorie data available
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart
        data={chartData}
        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
      >
        <XAxis 
          dataKey="formattedDate" 
          tick={{ fontSize: 10 }}
          tickLine={false}
          interval="preserveStartEnd"
        />
        <YAxis 
          tick={{ fontSize: 10 }}
          tickLine={false}
          label={{ 
            value: 'Net Calories', 
            angle: -90, 
            position: 'insideLeft', 
            style: { textAnchor: 'middle', fontSize: 11 } 
          }}
        />
        <Tooltip 
          labelFormatter={(label) => `Date: ${label}`}
          formatter={(value: number) => [
            `${value > 0 ? '+' : ''}${value} calories`, 
            value > 0 ? 'Surplus' : value < 0 ? 'Deficit' : 'Balance'
          ]}
          contentStyle={{ 
            fontSize: 11,
            backgroundColor: 'hsl(var(--card))',
            border: '1px solid hsl(var(--border))',
            borderRadius: '8px'
          }}
        />
        <Legend 
          verticalAlign="top" 
          wrapperStyle={{ fontSize: 11 }}
        />
        <ReferenceLine 
          y={0} 
          stroke="hsl(var(--muted-foreground))" 
          strokeDasharray="3 3"
          strokeWidth={1}
        />
        <Area 
          type="monotone" 
          dataKey="net" 
          stroke="#FF90BB" 
          fill="#FF90BB" 
          fillOpacity={0.6}
          strokeWidth={2}
          name="Net Calories"
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}
