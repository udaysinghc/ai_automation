
'use client';

import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { DailyData } from '@/lib/types';

interface WeightProgressChartProps {
  data: DailyData[];
}

export default function WeightProgressChart({ data }: WeightProgressChartProps) {
  const chartData = data
    .filter(day => day.weight !== null)
    .map(day => ({
      date: day.date,
      weight: day.weight?.weight || 0,
      formattedDate: new Date(day.date).toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric' 
      })
    }))
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  if (chartData.length === 0) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground">
        No weight data available
      </div>
    );
  }

  // Calculate Y-axis domain for better visualization
  const weights = chartData.map(d => d.weight);
  const minWeight = Math.min(...weights);
  const maxWeight = Math.max(...weights);
  const padding = (maxWeight - minWeight) * 0.1 || 5; // 10% padding or 5 lbs minimum
  
  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart
        data={chartData}
        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
      >
        <XAxis 
          dataKey="formattedDate" 
          tick={{ fontSize: 10 }}
          tickLine={false}
          interval="preserveStartEnd"
        />
        <YAxis 
          tick={{ fontSize: 10 }}
          tickLine={false}
          domain={[minWeight - padding, maxWeight + padding]}
          label={{ 
            value: 'Weight (lbs)', 
            angle: -90, 
            position: 'insideLeft', 
            style: { textAnchor: 'middle', fontSize: 11 } 
          }}
        />
        <Tooltip 
          labelFormatter={(label) => `Date: ${label}`}
          formatter={(value: number) => [`${value} lbs`, 'Weight']}
          contentStyle={{ 
            fontSize: 11,
            backgroundColor: 'hsl(var(--card))',
            border: '1px solid hsl(var(--border))',
            borderRadius: '8px'
          }}
        />
        <Legend 
          verticalAlign="top" 
          wrapperStyle={{ fontSize: 11 }}
        />
        <Line 
          type="monotone" 
          dataKey="weight" 
          stroke="#A19AD3" 
          strokeWidth={3}
          dot={{ r: 5, fill: '#A19AD3' }}
          activeDot={{ r: 7, fill: '#A19AD3' }}
          name="Weight"
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
