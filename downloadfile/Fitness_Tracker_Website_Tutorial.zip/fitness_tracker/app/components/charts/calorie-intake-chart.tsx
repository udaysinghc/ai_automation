
'use client';

import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { DailyData } from '@/lib/types';
import { getTotalCaloriesForDate } from '@/lib/storage';

interface CalorieIntakeChartProps {
  data: DailyData[];
}

export default function CalorieIntakeChart({ data }: CalorieIntakeChartProps) {
  const chartData = data
    .map(day => {
      const calories = getTotalCaloriesForDate(day.date);
      return {
        date: day.date,
        calories: calories.consumed,
        formattedDate: new Date(day.date).toLocaleDateString('en-US', { 
          month: 'short', 
          day: 'numeric' 
        })
      };
    })
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  if (chartData.length === 0) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground">
        No calorie intake data available
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart
        data={chartData}
        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
      >
        <XAxis 
          dataKey="formattedDate" 
          tick={{ fontSize: 10 }}
          tickLine={false}
          interval="preserveStartEnd"
        />
        <YAxis 
          tick={{ fontSize: 10 }}
          tickLine={false}
          label={{ 
            value: 'Calories', 
            angle: -90, 
            position: 'insideLeft', 
            style: { textAnchor: 'middle', fontSize: 11 } 
          }}
        />
        <Tooltip 
          labelFormatter={(label) => `Date: ${label}`}
          formatter={(value: number) => [`${value} calories`, 'Intake']}
          contentStyle={{ 
            fontSize: 11,
            backgroundColor: 'hsl(var(--card))',
            border: '1px solid hsl(var(--border))',
            borderRadius: '8px'
          }}
        />
        <Legend 
          verticalAlign="top" 
          wrapperStyle={{ fontSize: 11 }}
        />
        <Line 
          type="monotone" 
          dataKey="calories" 
          stroke="#60B5FF" 
          strokeWidth={2}
          dot={{ r: 4, fill: '#60B5FF' }}
          activeDot={{ r: 6, fill: '#60B5FF' }}
          name="Calorie Intake"
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
