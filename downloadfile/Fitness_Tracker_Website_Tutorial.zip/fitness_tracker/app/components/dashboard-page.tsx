
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Activity,
  Apple,
  Heart,
  Weight,
  Flame,
  Target
} from 'lucide-react';
import { getDailyData, getTotalCaloriesForDate, getWeightTrend } from '@/lib/storage';
import { DailyData } from '@/lib/types';
import CalorieIntakeChart from '@/components/charts/calorie-intake-chart';
import CaloriesBurnedChart from '@/components/charts/calories-burned-chart';
import NetCaloriesChart from '@/components/charts/net-calories-chart';
import WeightProgressChart from '@/components/charts/weight-progress-chart';

export default function DashboardPage() {
  const [dailyData, setDailyData] = useState<DailyData[]>([]);
  const [dateRange, setDateRange] = useState(30); // Default to last 30 days
  const [filteredData, setFilteredData] = useState<DailyData[]>([]);

  useEffect(() => {
    const data = getDailyData();
    setDailyData(data);
  }, []);

  useEffect(() => {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - dateRange);
    const filtered = dailyData.filter(day => new Date(day.date) >= cutoffDate);
    setFilteredData(filtered);
  }, [dailyData, dateRange]);

  // Calculate summary statistics
  const calculateSummary = () => {
    const totalDays = filteredData.length;
    const totalExercises = filteredData.reduce((sum, day) => sum + day.exercises.length, 0);
    const totalCardio = filteredData.reduce((sum, day) => sum + day.cardio.length, 0);
    const totalFoods = filteredData.reduce((sum, day) => sum + day.foods.length, 0);
    
    let totalCaloriesConsumed = 0;
    let totalCaloriesBurned = 0;
    
    filteredData.forEach(day => {
      const calories = getTotalCaloriesForDate(day.date);
      totalCaloriesConsumed += calories.consumed;
      totalCaloriesBurned += calories.burned;
    });

    const avgCaloriesConsumed = totalDays > 0 ? Math.round(totalCaloriesConsumed / totalDays) : 0;
    const avgCaloriesBurned = totalDays > 0 ? Math.round(totalCaloriesBurned / totalDays) : 0;
    const netCalories = totalCaloriesConsumed - totalCaloriesBurned;

    return {
      totalDays,
      totalExercises,
      totalCardio,
      totalFoods,
      avgCaloriesConsumed,
      avgCaloriesBurned,
      netCalories,
      totalCaloriesConsumed,
      totalCaloriesBurned,
    };
  };

  const summary = calculateSummary();
  const weightTrend = getWeightTrend();

  const StatCard = ({ 
    title, 
    value, 
    change, 
    icon: Icon, 
    color = "primary" 
  }: { 
    title: string; 
    value: string | number; 
    change?: string; 
    icon: any; 
    color?: string;
  }) => (
    <Card className="shadow-lg hover:shadow-xl transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold">{value}</p>
            {change && (
              <p className={`text-sm font-medium ${
                change.startsWith('+') ? 'text-red-600' : 
                change.startsWith('-') ? 'text-green-600' : 
                'text-muted-foreground'
              }`}>
                {change}
              </p>
            )}
          </div>
          <div className={`p-3 rounded-lg bg-${color}/10`}>
            <Icon className={`w-6 h-6 text-${color}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-primary">Fitness Dashboard</h1>
        <p className="text-muted-foreground">
          Visualize your progress and track your fitness goals
        </p>
      </div>

      {/* Date Range Filter */}
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-primary" />
            <span>Time Period</span>
          </CardTitle>
          <CardDescription>
            Select the time period for your dashboard analysis
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {[7, 14, 30, 60, 90].map((days) => (
              <Button
                key={days}
                variant={dateRange === days ? "default" : "outline"}
                onClick={() => setDateRange(days)}
                className="flex-1 min-w-0"
              >
                Last {days} days
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Activities"
          value={summary.totalExercises + summary.totalCardio}
          icon={Activity}
          color="blue-600"
        />
        <StatCard
          title="Avg Daily Calories"
          value={`${summary.avgCaloriesConsumed}`}
          icon={Apple}
          color="green-600"
        />
        <StatCard
          title="Avg Calories Burned"
          value={`${summary.avgCaloriesBurned}`}
          icon={Flame}
          color="red-600"
        />
        <StatCard
          title="Current Weight"
          value={weightTrend.current ? `${weightTrend.current} lbs` : 'N/A'}
          change={weightTrend.change ? `${weightTrend.change > 0 ? '+' : ''}${weightTrend.change.toFixed(1)} lbs` : undefined}
          icon={Weight}
          color="purple-600"
        />
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Apple className="w-5 h-5 text-green-600" />
              <span>Daily Calorie Intake</span>
            </CardTitle>
            <CardDescription>
              Track your daily calorie consumption over time
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <CalorieIntakeChart data={filteredData} />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Flame className="w-5 h-5 text-red-600" />
              <span>Daily Calories Burned</span>
            </CardTitle>
            <CardDescription>
              Monitor calories burned through cardio activities
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <CaloriesBurnedChart data={filteredData} />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="w-5 h-5 text-primary" />
              <span>Net Calorie Balance</span>
            </CardTitle>
            <CardDescription>
              Visualize your calorie surplus or deficit
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <NetCaloriesChart data={filteredData} />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Weight className="w-5 h-5 text-purple-600" />
              <span>Weight Progress</span>
            </CardTitle>
            <CardDescription>
              Track your weight changes over time
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <WeightProgressChart data={filteredData} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">Activity Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Total Exercise Sessions</span>
                <Badge variant="secondary">{summary.totalExercises}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Total Cardio Sessions</span>
                <Badge variant="secondary">{summary.totalCardio}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Food Entries</span>
                <Badge variant="secondary">{summary.totalFoods}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Active Days</span>
                <Badge variant="secondary">{summary.totalDays}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">Calorie Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Total Consumed</span>
                <Badge variant="secondary">{summary.totalCaloriesConsumed.toLocaleString()}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Total Burned</span>
                <Badge variant="secondary">{summary.totalCaloriesBurned.toLocaleString()}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Net Balance</span>
                <Badge variant={summary.netCalories > 0 ? "destructive" : "default"}>
                  {summary.netCalories > 0 ? '+' : ''}{summary.netCalories.toLocaleString()}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Daily Average</span>
                <Badge variant="secondary">{summary.avgCaloriesConsumed}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">Weight Tracking</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Current Weight</span>
                <Badge variant="secondary">
                  {weightTrend.current ? `${weightTrend.current} lbs` : 'N/A'}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Previous Weight</span>
                <Badge variant="secondary">
                  {weightTrend.previous ? `${weightTrend.previous} lbs` : 'N/A'}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Change</span>
                <div className="flex items-center space-x-1">
                  {weightTrend.change !== null && (
                    <>
                      {weightTrend.change > 0 ? (
                        <TrendingUp className="w-4 h-4 text-red-500" />
                      ) : weightTrend.change < 0 ? (
                        <TrendingDown className="w-4 h-4 text-green-500" />
                      ) : null}
                      <Badge variant={weightTrend.change > 0 ? "destructive" : "default"}>
                        {weightTrend.change > 0 ? '+' : ''}{weightTrend.change.toFixed(1)} lbs
                      </Badge>
                    </>
                  )}
                  {weightTrend.change === null && (
                    <Badge variant="secondary">N/A</Badge>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
