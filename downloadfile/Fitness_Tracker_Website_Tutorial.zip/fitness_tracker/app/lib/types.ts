
export interface ExerciseEntry {
  id: string;
  date: string;
  exerciseType: string;
  weight: number;
  reps: number;
  timestamp: number;
}

export interface CardioEntry {
  id: string;
  date: string;
  cardioType: string;
  duration: number; // in minutes
  caloriesBurned: number;
  timestamp: number;
}

export interface FoodEntry {
  id: string;
  date: string;
  foodItem: string;
  calories: number;
  timestamp: number;
}

export interface WeightEntry {
  id: string;
  date: string;
  weight: number;
  timestamp: number;
}

export interface DailyData {
  date: string;
  exercises: ExerciseEntry[];
  cardio: CardioEntry[];
  foods: FoodEntry[];
  weight: WeightEntry | null;
}

export type EntryType = 'exercise' | 'cardio' | 'food' | 'weight';

export const EXERCISE_TYPES = [
  'Push-ups',
  'Pull-ups',
  'Squats',
  'Deadlifts',
  'Bench Press',
  'Shoulder Press',
  'Bicep Curls',
  'Tricep Dips',
  'Lunges',
  'Planks',
  'Burpees',
  'Mountain Climbers',
  'Other'
];

export const CARDIO_TYPES = [
  'Running',
  'Walking',
  'Cycling',
  'Swimming',
  'Dancing',
  'Rowing',
  'Elliptical',
  'Stair Climbing',
  'Jump Rope',
  'HIIT',
  'Other'
];
