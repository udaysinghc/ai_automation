
import { ExerciseEntry, CardioEntry, FoodEntry, WeightEntry, DailyData } from './types';

const STORAGE_KEYS = {
  EXERCISES: 'fitness_tracker_exercises',
  CARDIO: 'fitness_tracker_cardio',
  FOODS: 'fitness_tracker_foods',
  WEIGHTS: 'fitness_tracker_weights',
};

// Generic storage functions
function getStorageData<T>(key: string): T[] {
  if (typeof window === 'undefined') return [];
  
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error(`Error reading ${key} from localStorage:`, error);
    return [];
  }
}

function setStorageData<T>(key: string, data: T[]): void {
  if (typeof window === 'undefined') return;
  
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error writing ${key} to localStorage:`, error);
  }
}

// Exercise functions
export function saveExercise(exercise: Omit<ExerciseEntry, 'id' | 'timestamp'>): void {
  const exercises = getStorageData<ExerciseEntry>(STORAGE_KEYS.EXERCISES);
  const newExercise: ExerciseEntry = {
    ...exercise,
    id: Date.now().toString(),
    timestamp: Date.now(),
  };
  
  exercises.push(newExercise);
  setStorageData(STORAGE_KEYS.EXERCISES, exercises);
}

export function getExercises(): ExerciseEntry[] {
  return getStorageData<ExerciseEntry>(STORAGE_KEYS.EXERCISES);
}

// Cardio functions
export function saveCardio(cardio: Omit<CardioEntry, 'id' | 'timestamp'>): void {
  const cardioEntries = getStorageData<CardioEntry>(STORAGE_KEYS.CARDIO);
  const newCardio: CardioEntry = {
    ...cardio,
    id: Date.now().toString(),
    timestamp: Date.now(),
  };
  
  cardioEntries.push(newCardio);
  setStorageData(STORAGE_KEYS.CARDIO, cardioEntries);
}

export function getCardio(): CardioEntry[] {
  return getStorageData<CardioEntry>(STORAGE_KEYS.CARDIO);
}

// Food functions
export function saveFood(food: Omit<FoodEntry, 'id' | 'timestamp'>): void {
  const foods = getStorageData<FoodEntry>(STORAGE_KEYS.FOODS);
  const newFood: FoodEntry = {
    ...food,
    id: Date.now().toString(),
    timestamp: Date.now(),
  };
  
  foods.push(newFood);
  setStorageData(STORAGE_KEYS.FOODS, foods);
}

export function getFoods(): FoodEntry[] {
  return getStorageData<FoodEntry>(STORAGE_KEYS.FOODS);
}

// Weight functions
export function saveWeight(weight: Omit<WeightEntry, 'id' | 'timestamp'>): void {
  const weights = getStorageData<WeightEntry>(STORAGE_KEYS.WEIGHTS);
  const newWeight: WeightEntry = {
    ...weight,
    id: Date.now().toString(),
    timestamp: Date.now(),
  };
  
  // Remove existing weight entry for the same date
  const filteredWeights = weights.filter(w => w.date !== weight.date);
  filteredWeights.push(newWeight);
  
  setStorageData(STORAGE_KEYS.WEIGHTS, filteredWeights);
}

export function getWeights(): WeightEntry[] {
  return getStorageData<WeightEntry>(STORAGE_KEYS.WEIGHTS);
}

// Combined data functions
export function getDailyData(): DailyData[] {
  const exercises = getExercises();
  const cardio = getCardio();
  const foods = getFoods();
  const weights = getWeights();

  // Get all unique dates
  const allDates = new Set<string>();
  exercises.forEach(e => allDates.add(e.date));
  cardio.forEach(c => allDates.add(c.date));
  foods.forEach(f => allDates.add(f.date));
  weights.forEach(w => allDates.add(w.date));

  // Create daily data objects
  const dailyData: DailyData[] = Array.from(allDates).map(date => ({
    date,
    exercises: exercises.filter(e => e.date === date),
    cardio: cardio.filter(c => c.date === date),
    foods: foods.filter(f => f.date === date),
    weight: weights.find(w => w.date === date) || null,
  }));

  // Sort by date (most recent first)
  return dailyData.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}

// Utility functions
export function getTotalCaloriesForDate(date: string): { consumed: number; burned: number; net: number } {
  const foods = getFoods().filter(f => f.date === date);
  const cardioEntries = getCardio().filter(c => c.date === date);

  const consumed = foods.reduce((sum, food) => sum + food.calories, 0);
  const burned = cardioEntries.reduce((sum, cardio) => sum + cardio.caloriesBurned, 0);
  const net = consumed - burned;

  return { consumed, burned, net };
}

export function getWeightTrend(): { current: number | null; previous: number | null; change: number | null } {
  const weights = getWeights().sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  if (weights.length === 0) return { current: null, previous: null, change: null };
  if (weights.length === 1) return { current: weights[0].weight, previous: null, change: null };

  const current = weights[0].weight;
  const previous = weights[1].weight;
  const change = current - previous;

  return { current, previous, change };
}

// Clear all data function
export function clearAllData(): void {
  if (typeof window === 'undefined') return;
  
  Object.values(STORAGE_KEYS).forEach(key => {
    localStorage.removeItem(key);
  });
}
