
'use client';

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { DailyData } from '@/lib/types';
import { getTotalCaloriesForDate } from '@/lib/storage';

interface CaloriesBurnedChartProps {
  data: DailyData[];
}

export default function CaloriesBurnedChart({ data }: CaloriesBurnedChartProps) {
  const chartData = data
    .map(day => {
      const calories = getTotalCaloriesForDate(day.date);
      return {
        date: day.date,
        burned: calories.burned,
        formattedDate: new Date(day.date).toLocaleDateString('en-US', { 
          month: 'short', 
          day: 'numeric' 
        })
      };
    })
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  if (chartData.length === 0) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground">
        No calories burned data available
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={chartData}
        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
      >
        <XAxis 
          dataKey="formattedDate" 
          tick={{ fontSize: 10 }}
          tickLine={false}
          interval="preserveStartEnd"
        />
        <YAxis 
          tick={{ fontSize: 10 }}
          tickLine={false}
          label={{ 
            value: 'Calories', 
            angle: -90, 
            position: 'insideLeft', 
            style: { textAnchor: 'middle', fontSize: 11 } 
          }}
        />
        <Tooltip 
          labelFormatter={(label) => `Date: ${label}`}
          formatter={(value: number) => [`${value} calories`, 'Burned']}
          contentStyle={{ 
            fontSize: 11,
            backgroundColor: 'hsl(var(--card))',
            border: '1px solid hsl(var(--border))',
            borderRadius: '8px'
          }}
        />
        <Legend 
          verticalAlign="top" 
          wrapperStyle={{ fontSize: 11 }}
        />
        <Bar 
          dataKey="burned" 
          fill="#FF9149" 
          name="Calories Burned"
          radius={[4, 4, 0, 0]}
        />
      </BarChart>
    </ResponsiveContainer>
  );
}
