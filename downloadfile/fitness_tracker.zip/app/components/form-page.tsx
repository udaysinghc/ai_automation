
'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Activity, Heart, Apple, Weight } from 'lucide-react';
import ExerciseForm from '@/components/forms/exercise-form';
import CardioForm from '@/components/forms/cardio-form';
import FoodForm from '@/components/forms/food-form';
import WeightForm from '@/components/forms/weight-form';

export default function FormPage() {
  const [activeForm, setActiveForm] = useState('exercise');

  const forms = [
    {
      id: 'exercise',
      label: 'Exercise',
      icon: Activity,
      description: 'Log your strength training and exercises',
      component: <ExerciseForm />,
    },
    {
      id: 'cardio',
      label: 'Cardio',
      icon: Heart,
      description: 'Track your cardiovascular activities',
      component: <CardioForm />,
    },
    {
      id: 'food',
      label: 'Nutrition',
      icon: Apple,
      description: 'Record your food intake and calories',
      component: <FoodForm />,
    },
    {
      id: 'weight',
      label: 'Weight',
      icon: Weight,
      description: 'Monitor your daily weight measurements',
      component: <WeightForm />,
    },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-primary">Track Your Fitness Journey</h1>
        <p className="text-muted-foreground">
          Log your daily activities, nutrition, and progress in one place
        </p>
      </div>

      <Tabs value={activeForm} onValueChange={setActiveForm} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-card">
          {forms.map((form) => {
            const Icon = form.icon;
            return (
              <TabsTrigger
                key={form.id}
                value={form.id}
                className="flex items-center space-x-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                <Icon className="w-4 h-4" />
                <span className="hidden sm:inline">{form.label}</span>
              </TabsTrigger>
            );
          })}
        </TabsList>

        {forms.map((form) => (
          <TabsContent key={form.id} value={form.id} className="mt-6">
            <Card className="shadow-lg border-primary/20">
              <CardHeader className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-t-lg">
                <CardTitle className="flex items-center space-x-2">
                  <form.icon className="w-5 h-5 text-primary" />
                  <span>{form.label} Tracking</span>
                </CardTitle>
                <CardDescription>{form.description}</CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                {form.component}
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
