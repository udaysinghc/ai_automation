
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Calendar, Filter, Activity, Heart, Apple, Weight, ChevronDown, ChevronUp } from 'lucide-react';
import { getDailyData, getTotalCaloriesForDate } from '@/lib/storage';
import { DailyData } from '@/lib/types';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function ProgressPage() {
  const [dailyData, setDailyData] = useState<DailyData[]>([]);
  const [filteredData, setFilteredData] = useState<DailyData[]>([]);
  const [dateFilter, setDateFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());

  useEffect(() => {
    const data = getDailyData();
    setDailyData(data);
    setFilteredData(data);
  }, []);

  useEffect(() => {
    let filtered = dailyData;

    if (dateFilter) {
      filtered = filtered.filter(day => day.date >= dateFilter);
    }

    if (typeFilter !== 'all') {
      filtered = filtered.filter(day => {
        switch (typeFilter) {
          case 'exercise':
            return day.exercises.length > 0;
          case 'cardio':
            return day.cardio.length > 0;
          case 'food':
            return day.foods.length > 0;
          case 'weight':
            return day.weight !== null;
          default:
            return true;
        }
      });
    }

    setFilteredData(filtered);
  }, [dailyData, dateFilter, typeFilter]);

  const toggleRowExpansion = (date: string) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(date)) {
      newExpanded.delete(date);
    } else {
      newExpanded.add(date);
    }
    setExpandedRows(newExpanded);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getActivitySummary = (day: DailyData) => {
    const activities = [];
    if (day.exercises.length > 0) activities.push(`${day.exercises.length} exercises`);
    if (day.cardio.length > 0) activities.push(`${day.cardio.length} cardio`);
    if (day.foods.length > 0) activities.push(`${day.foods.length} foods`);
    if (day.weight) activities.push('weight logged');
    return activities.join(', ') || 'No activities';
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-primary">Progress Tracking</h1>
        <p className="text-muted-foreground">
          Monitor your fitness journey with detailed daily progress
        </p>
      </div>

      {/* Filters */}
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Filter className="w-5 h-5 text-primary" />
            <span>Filter Data</span>
          </CardTitle>
          <CardDescription>
            Filter your progress data by date and activity type
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">From Date</label>
              <Input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="border-primary/30 focus:border-primary"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Activity Type</label>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="border-primary/30 focus:border-primary">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Activities</SelectItem>
                  <SelectItem value="exercise">Exercise Only</SelectItem>
                  <SelectItem value="cardio">Cardio Only</SelectItem>
                  <SelectItem value="food">Food Only</SelectItem>
                  <SelectItem value="weight">Weight Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Progress Table */}
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-primary" />
            <span>Daily Progress</span>
          </CardTitle>
          <CardDescription>
            Click on any row to view detailed information
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredData.length === 0 ? (
            <div className="text-center py-8">
              <Calendar className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No data found for the selected filters</p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredData.map((day) => {
                const isExpanded = expandedRows.has(day.date);
                const calories = getTotalCaloriesForDate(day.date);
                
                return (
                  <div key={day.date} className="border border-primary/20 rounded-lg overflow-hidden">
                    <Button
                      variant="ghost"
                      onClick={() => toggleRowExpansion(day.date)}
                      className="w-full p-4 flex items-center justify-between hover:bg-accent/50 rounded-none"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="text-left">
                          <div className="font-semibold">{formatDate(day.date)}</div>
                          <div className="text-sm text-muted-foreground">
                            {getActivitySummary(day)}
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          {day.exercises.length > 0 && (
                            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                              <Activity className="w-3 h-3 mr-1" />
                              {day.exercises.length}
                            </Badge>
                          )}
                          {day.cardio.length > 0 && (
                            <Badge variant="secondary" className="bg-red-100 text-red-800">
                              <Heart className="w-3 h-3 mr-1" />
                              {day.cardio.length}
                            </Badge>
                          )}
                          {day.foods.length > 0 && (
                            <Badge variant="secondary" className="bg-green-100 text-green-800">
                              <Apple className="w-3 h-3 mr-1" />
                              {day.foods.length}
                            </Badge>
                          )}
                          {day.weight && (
                            <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                              <Weight className="w-3 h-3 mr-1" />
                              {day.weight.weight}lb
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="text-right text-sm">
                          <div className="text-muted-foreground">Net Calories</div>
                          <div className={`font-semibold ${
                            calories.net > 0 ? 'text-red-600' : 
                            calories.net < 0 ? 'text-green-600' : 
                            'text-muted-foreground'
                          }`}>
                            {calories.net > 0 ? '+' : ''}{calories.net}
                          </div>
                        </div>
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-muted-foreground" />
                        )}
                      </div>
                    </Button>
                    
                    {isExpanded && (
                      <div className="p-4 bg-muted/20 border-t">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                          {/* Exercises */}
                          <div className="space-y-2">
                            <h4 className="font-semibold flex items-center">
                              <Activity className="w-4 h-4 mr-2 text-blue-600" />
                              Exercises
                            </h4>
                            {day.exercises.length > 0 ? (
                              <div className="space-y-1">
                                {day.exercises.map((exercise) => (
                                  <div key={exercise.id} className="text-sm p-2 bg-blue-50 rounded">
                                    <div className="font-medium">{exercise.exerciseType}</div>
                                    <div className="text-muted-foreground">
                                      {exercise.weight}lbs × {exercise.reps} reps
                                    </div>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="text-sm text-muted-foreground">No exercises logged</p>
                            )}
                          </div>

                          {/* Cardio */}
                          <div className="space-y-2">
                            <h4 className="font-semibold flex items-center">
                              <Heart className="w-4 h-4 mr-2 text-red-600" />
                              Cardio
                            </h4>
                            {day.cardio.length > 0 ? (
                              <div className="space-y-1">
                                {day.cardio.map((cardio) => (
                                  <div key={cardio.id} className="text-sm p-2 bg-red-50 rounded">
                                    <div className="font-medium">{cardio.cardioType}</div>
                                    <div className="text-muted-foreground">
                                      {cardio.duration} min • {cardio.caloriesBurned} cal
                                    </div>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="text-sm text-muted-foreground">No cardio logged</p>
                            )}
                          </div>

                          {/* Food */}
                          <div className="space-y-2">
                            <h4 className="font-semibold flex items-center">
                              <Apple className="w-4 h-4 mr-2 text-green-600" />
                              Food
                            </h4>
                            {day.foods.length > 0 ? (
                              <div className="space-y-1">
                                {day.foods.map((food) => (
                                  <div key={food.id} className="text-sm p-2 bg-green-50 rounded">
                                    <div className="font-medium">{food.foodItem}</div>
                                    <div className="text-muted-foreground">
                                      {food.calories} calories
                                    </div>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="text-sm text-muted-foreground">No food logged</p>
                            )}
                          </div>

                          {/* Weight */}
                          <div className="space-y-2">
                            <h4 className="font-semibold flex items-center">
                              <Weight className="w-4 h-4 mr-2 text-purple-600" />
                              Weight
                            </h4>
                            {day.weight ? (
                              <div className="text-sm p-2 bg-purple-50 rounded">
                                <div className="font-medium">{day.weight.weight} lbs</div>
                                <div className="text-muted-foreground">
                                  {formatDate(day.weight.date)}
                                </div>
                              </div>
                            ) : (
                              <p className="text-sm text-muted-foreground">No weight logged</p>
                            )}
                          </div>
                        </div>

                        {/* Daily Summary */}
                        <div className="mt-4 p-3 bg-primary/10 rounded-lg">
                          <h4 className="font-semibold mb-2">Daily Summary</h4>
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">Calories Consumed:</span>
                              <span className="ml-2 font-medium">{calories.consumed}</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Calories Burned:</span>
                              <span className="ml-2 font-medium">{calories.burned}</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Net Calories:</span>
                              <span className={`ml-2 font-medium ${
                                calories.net > 0 ? 'text-red-600' : 
                                calories.net < 0 ? 'text-green-600' : 
                                'text-muted-foreground'
                              }`}>
                                {calories.net > 0 ? '+' : ''}{calories.net}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
