
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Dumbbell, Plus, Check } from 'lucide-react';
import { EXERCISE_TYPES } from '@/lib/types';
import { saveExercise } from '@/lib/storage';
import { toast } from 'sonner';

export default function ExerciseForm() {
  const [formData, setFormData] = useState({
    exerciseType: '',
    weight: '',
    reps: '',
    date: new Date().toISOString().split('T')[0],
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.exerciseType || !formData.weight || !formData.reps) {
      toast.error('Please fill in all fields');
      return;
    }

    setIsSubmitting(true);

    try {
      saveExercise({
        date: formData.date,
        exerciseType: formData.exerciseType,
        weight: parseFloat(formData.weight),
        reps: parseInt(formData.reps),
      });

      toast.success('Exercise logged successfully!');
      
      // Reset form
      setFormData({
        exerciseType: '',
        weight: '',
        reps: '',
        date: new Date().toISOString().split('T')[0],
      });
    } catch (error) {
      toast.error('Failed to log exercise. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="border-primary/20">
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="date" className="text-sm font-medium">
                Date
              </Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="border-primary/30 focus:border-primary"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="exercise-type" className="text-sm font-medium">
                Exercise Type
              </Label>
              <Select
                value={formData.exerciseType}
                onValueChange={(value) => setFormData({ ...formData, exerciseType: value })}
              >
                <SelectTrigger className="border-primary/30 focus:border-primary">
                  <SelectValue placeholder="Select exercise type" />
                </SelectTrigger>
                <SelectContent>
                  {EXERCISE_TYPES.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="weight" className="text-sm font-medium">
                Weight (lbs)
              </Label>
              <div className="relative">
                <Dumbbell className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary w-4 h-4" />
                <Input
                  id="weight"
                  type="number"
                  step="0.1"
                  min="0"
                  placeholder="0.0"
                  value={formData.weight}
                  onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                  className="pl-10 border-primary/30 focus:border-primary"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reps" className="text-sm font-medium">
                Repetitions
              </Label>
              <Input
                id="reps"
                type="number"
                min="1"
                placeholder="0"
                value={formData.reps}
                onChange={(e) => setFormData({ ...formData, reps: e.target.value })}
                className="border-primary/30 focus:border-primary"
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium py-3 rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Logging Exercise...
              </>
            ) : (
              <>
                <Plus className="w-4 h-4 mr-2" />
                Log Exercise
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
