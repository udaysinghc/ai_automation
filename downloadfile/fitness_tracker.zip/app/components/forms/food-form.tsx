
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Apple, Plus, Utensils, Zap } from 'lucide-react';
import { saveFood } from '@/lib/storage';
import { toast } from 'sonner';

export default function FoodForm() {
  const [formData, setFormData] = useState({
    foodItem: '',
    calories: '',
    date: new Date().toISOString().split('T')[0],
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.foodItem || !formData.calories) {
      toast.error('Please fill in all fields');
      return;
    }

    setIsSubmitting(true);

    try {
      saveFood({
        date: formData.date,
        foodItem: formData.foodItem.trim(),
        calories: parseInt(formData.calories),
      });

      toast.success('Food intake logged successfully!');
      
      // Reset form
      setFormData({
        foodItem: '',
        calories: '',
        date: new Date().toISOString().split('T')[0],
      });
    } catch (error) {
      toast.error('Failed to log food intake. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="border-primary/20">
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="food-date" className="text-sm font-medium">
                Date
              </Label>
              <Input
                id="food-date"
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="border-primary/30 focus:border-primary"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="food-item" className="text-sm font-medium">
                Food Item
              </Label>
              <div className="relative">
                <Utensils className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary w-4 h-4" />
                <Input
                  id="food-item"
                  type="text"
                  placeholder="e.g., Chicken Breast, Apple, Oatmeal"
                  value={formData.foodItem}
                  onChange={(e) => setFormData({ ...formData, foodItem: e.target.value })}
                  className="pl-10 border-primary/30 focus:border-primary"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="calories" className="text-sm font-medium">
                Calories
              </Label>
              <div className="relative">
                <Zap className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary w-4 h-4" />
                <Input
                  id="calories"
                  type="number"
                  min="0"
                  placeholder="0"
                  value={formData.calories}
                  onChange={(e) => setFormData({ ...formData, calories: e.target.value })}
                  className="pl-10 border-primary/30 focus:border-primary"
                />
              </div>
            </div>
          </div>

          <div className="bg-muted/50 p-4 rounded-lg">
            <h3 className="font-medium text-sm mb-2 flex items-center">
              <Apple className="w-4 h-4 mr-2 text-primary" />
              Quick Calorie Reference
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm text-muted-foreground">
              <div>Apple: ~80 cal</div>
              <div>Banana: ~100 cal</div>
              <div>Chicken Breast: ~165 cal/100g</div>
              <div>Rice: ~130 cal/100g</div>
            </div>
          </div>

          <Button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium py-3 rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Logging Food...
              </>
            ) : (
              <>
                <Plus className="w-4 h-4 mr-2" />
                Log Food Intake
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
