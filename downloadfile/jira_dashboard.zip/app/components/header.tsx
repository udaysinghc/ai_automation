
'use client';

import { RefreshCw, Bell, Search, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

export function Header() {
  const handleRefresh = () => {
    // Placeholder for refresh functionality
    console.log('Refreshing dashboard...');
  };

  return (
    <header className="bg-card/50 backdrop-blur-md border-b border-border/50 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="ml-14 md:ml-0">
            <h1 className="text-2xl font-bold">High Priority Tasks</h1>
            <p className="text-sm text-muted-foreground">
              Monitor and manage critical project tasks
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {/* Search */}
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search tasks..."
              className="pl-10 w-64"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="icon"
              onClick={handleRefresh}
              className="relative"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>

            <Button variant="outline" size="icon" className="relative">
              <Bell className="h-4 w-4" />
              <Badge
                variant="destructive"
                className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 text-xs"
              >
                3
              </Badge>
            </Button>

            <Button className="hidden md:flex">
              <Plus className="h-4 w-4 mr-2" />
              New Task
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
