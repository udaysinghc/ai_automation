
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { ChartData } from '@/lib/types';

interface TaskProgressChartProps {
  data: ChartData['taskProgress'];
}

export function TaskProgressChart({ data }: TaskProgressChartProps) {
  const chartData = data ?? [];

  return (
    <Card className="chart-container">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Task Progress Over Time</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
            <XAxis 
              dataKey="date" 
              tickLine={false}
              tick={{ fontSize: 10 }}
              label={{ 
                value: 'Date', 
                position: 'insideBottom', 
                offset: -15, 
                style: { textAnchor: 'middle', fontSize: 11 } 
              }}
            />
            <YAxis 
              tickLine={false}
              tick={{ fontSize: 10 }}
              label={{ 
                value: 'Tasks', 
                angle: -90, 
                position: 'insideLeft', 
                style: { textAnchor: 'middle', fontSize: 11 } 
              }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '6px',
                fontSize: '11px'
              }}
            />
            <Legend 
              verticalAlign="top"
              align="center"
              wrapperStyle={{ fontSize: '11px' }}
            />
            <Line 
              type="monotone" 
              dataKey="created" 
              stroke="#60B5FF" 
              strokeWidth={2}
              name="Created"
            />
            <Line 
              type="monotone" 
              dataKey="completed" 
              stroke="#80D8C3" 
              strokeWidth={2}
              name="Completed"
            />
            <Line 
              type="monotone" 
              dataKey="resolved" 
              stroke="#FF9149" 
              strokeWidth={2}
              name="Resolved"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
