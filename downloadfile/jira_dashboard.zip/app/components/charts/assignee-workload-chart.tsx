
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { ChartData } from '@/lib/types';

interface AssigneeWorkloadChartProps {
  data: ChartData['assigneeWorkload'];
}

export function AssigneeWorkloadChart({ data }: AssigneeWorkloadChartProps) {
  const chartData = data ?? [];

  return (
    <Card className="chart-container">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Team Workload</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 40 }}>
            <XAxis 
              dataKey="assignee" 
              tickLine={false}
              tick={{ fontSize: 10 }}
              angle={-45}
              textAnchor="end"
              height={60}
              label={{ 
                value: 'Team Members', 
                position: 'insideBottom', 
                offset: -35, 
                style: { textAnchor: 'middle', fontSize: 11 } 
              }}
            />
            <YAxis 
              tickLine={false}
              tick={{ fontSize: 10 }}
              label={{ 
                value: 'Tasks', 
                angle: -90, 
                position: 'insideLeft', 
                style: { textAnchor: 'middle', fontSize: 11 } 
              }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '6px',
                fontSize: '11px'
              }}
            />
            <Legend 
              verticalAlign="top"
              align="center"
              wrapperStyle={{ fontSize: '11px' }}
            />
            <Bar dataKey="inProgress" stackId="a" fill="#FF9149" name="In Progress" />
            <Bar dataKey="completed" stackId="a" fill="#80D8C3" name="Completed" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
