
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  MoreHorizontal, 
  Search, 
  Filter,
  Bug,
  FileText,
  Layers,
  CheckSquare,
  AlertTriangle,
  Clock,
  CheckCircle,
  Users,
  Calendar
} from 'lucide-react';
import { JiraTask } from '@/lib/types';
import { format } from 'date-fns';

interface TaskListProps {
  tasks: JiraTask[];
}

const taskTypeIcons = {
  Bug: Bug,
  Story: FileText,
  Epic: Layers,
  Task: CheckSquare,
  Subtask: CheckSquare
};

const priorityColors = {
  Critical: 'priority-critical',
  High: 'priority-high',
  Medium: 'priority-medium',
  Low: 'priority-low'
};

const statusColors = {
  'To Do': 'bg-gray-500/10 text-gray-400',
  'In Progress': 'bg-blue-500/10 text-blue-400',
  'Code Review': 'bg-yellow-500/10 text-yellow-400',
  'Testing': 'bg-purple-500/10 text-purple-400',
  'Done': 'bg-green-500/10 text-green-400'
};

export function TaskList({ tasks }: TaskListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  const filteredTasks = tasks?.filter(task => {
    const matchesSearch = task?.summary?.toLowerCase()?.includes(searchTerm.toLowerCase()) ?? false;
    const matchesPriority = priorityFilter === 'all' || task?.priority === priorityFilter;
    const matchesStatus = statusFilter === 'all' || task?.status === statusFilter;
    return matchesSearch && matchesPriority && matchesStatus;
  }) ?? [];

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MMM dd, yyyy');
    } catch {
      return 'N/A';
    }
  };

  const isOverdue = (dueDate?: string, status?: string) => {
    if (!dueDate || status === 'Done') return false;
    return new Date(dueDate) < new Date();
  };

  return (
    <Card className="chart-container">
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0">
          <CardTitle className="text-lg font-semibold">High Priority Tasks</CardTitle>
          
          <div className="flex flex-col md:flex-row gap-3 w-full md:w-auto">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search tasks..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full md:w-64"
              />
            </div>
            
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-full md:w-32">
                <SelectValue placeholder="Priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priority</SelectItem>
                <SelectItem value="Critical">Critical</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Low">Low</SelectItem>
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-32">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="To Do">To Do</SelectItem>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Code Review">Code Review</SelectItem>
                <SelectItem value="Testing">Testing</SelectItem>
                <SelectItem value="Done">Done</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {filteredTasks.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Filter className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No tasks match the selected criteria</p>
            </div>
          ) : (
            filteredTasks.map((task) => {
              const TaskIcon = taskTypeIcons[task.taskType];
              const isTaskOverdue = isOverdue(task.dueDate, task.status);
              
              return (
                <div
                  key={task.id}
                  className="flex items-center justify-between p-4 rounded-lg border border-border/50 hover:bg-accent/50 transition-colors"
                >
                  <div className="flex items-center space-x-4 flex-1">
                    <div className="flex items-center space-x-2">
                      <TaskIcon className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-mono text-muted-foreground">
                        {task.key}
                      </span>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium truncate">{task.summary}</h4>
                      <div className="flex items-center space-x-4 mt-2">
                        <Badge className={priorityColors[task.priority]}>
                          {task.priority}
                        </Badge>
                        <Badge variant="outline" className={statusColors[task.status]}>
                          {task.status}
                        </Badge>
                        <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                          <Users className="h-3 w-3" />
                          <span>{task.assignee.name}</span>
                        </div>
                        {task.dueDate && (
                          <div className={`flex items-center space-x-1 text-sm ${
                            isTaskOverdue ? 'text-red-400' : 'text-muted-foreground'
                          }`}>
                            <Calendar className="h-3 w-3" />
                            <span>{formatDate(task.dueDate)}</span>
                            {isTaskOverdue && (
                              <AlertTriangle className="h-3 w-3 text-red-400" />
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
}
