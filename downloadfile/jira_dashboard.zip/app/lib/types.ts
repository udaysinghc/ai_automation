
export interface JiraTask {
  id: string;
  key: string;
  summary: string;
  description: string;
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'To Do' | 'In Progress' | 'Code Review' | 'Testing' | 'Done';
  assignee: {
    id: string;
    name: string;
    email: string;
    avatarUrl?: string;
  };
  reporter: {
    id: string;
    name: string;
    email: string;
  };
  taskType: 'Bug' | 'Story' | 'Epic' | 'Task' | 'Subtask';
  created: string;
  updated: string;
  dueDate?: string;
  estimatedHours?: number;
  timeSpent?: number;
  storyPoints?: number;
  labels: string[];
  project: {
    id: string;
    name: string;
    key: string;
  };
}

export interface DashboardMetrics {
  totalTasks: number;
  overdueTasks: number;
  completedTasks: number;
  criticalTasks: number;
  highPriorityTasks: number;
  averageCompletionTime: number;
  teamVelocity: number;
}

export interface ChartData {
  statusDistribution: {
    name: string;
    value: number;
    color: string;
  }[];
  priorityBreakdown: {
    priority: string;
    count: number;
    color: string;
  }[];
  assigneeWorkload: {
    assignee: string;
    tasks: number;
    completed: number;
    inProgress: number;
  }[];
  taskProgress: {
    date: string;
    created: number;
    completed: number;
    resolved: number;
  }[];
}

export interface FilterOptions {
  priority: string[];
  status: string[];
  assignee: string[];
  taskType: string[];
  dateRange: {
    start: string;
    end: string;
  };
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  role: string;
}
