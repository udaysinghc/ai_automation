
import { HistoryTimeline } from "@/components/history-timeline";
import { ArchitecturalEvolution } from "@/components/architectural-evolution";
import { CulturalImpact } from "@/components/cultural-impact";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";

export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background">
      <div className="bg-gradient-to-r from-secondary to-primary text-white py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center mb-6">
            <Link 
              href="/"
              className="flex items-center space-x-2 text-white/80 hover:text-white transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Home</span>
            </Link>
          </div>
          
          <div className="max-w-4xl">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-shadow">
              The History of the Louvre
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-white/90 leading-relaxed">
              An extraordinary journey spanning over 800 years, from medieval fortress to the world's most celebrated museum.
            </p>
          </div>
        </div>
      </div>

      <HistoryTimeline />
      <ArchitecturalEvolution />
      <CulturalImpact />
    </div>
  );
}
