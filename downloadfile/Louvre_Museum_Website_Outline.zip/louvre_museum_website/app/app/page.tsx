
import { Hero } from "@/components/hero";
import { MuseumOverview } from "@/components/museum-overview";
import { FeaturedArtworks } from "@/components/featured-artworks";
import { MuseumStats } from "@/components/museum-stats";
import { CallToAction } from "@/components/call-to-action";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Hero />
      <MuseumOverview />
      <FeaturedArtworks />
      <MuseumStats />
      <CallToAction />
    </div>
  );
}
