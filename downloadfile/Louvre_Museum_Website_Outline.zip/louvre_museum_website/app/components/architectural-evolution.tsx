
"use client";

import { useEffect, useState } from "react";
import { Shield, Columns, Building2, Zap } from "lucide-react";

export function ArchitecturalEvolution() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById("architectural-evolution");
    if (element) {
      observer.observe(element);
    }

    return () => observer.disconnect();
  }, []);

  const architecturalPeriods = [
    {
      icon: Shield,
      period: "Medieval Period",
      dates: "1190-1364",
      style: "Fortress Architecture",
      features: [
        "Thick curtain walls with defensive capabilities",
        "Ten round defensive towers strategically positioned",
        "Large moat approximately 10 meters wide",
        "Central Grand Tower reaching 30 meters in height"
      ],
      color: "bg-slate-600"
    },
    {
      icon: Columns,
      period: "Renaissance",
      dates: "1364-1682",
      style: "Classical Proportions",
      features: [
        "Symmetrical layouts and classical proportions",
        "Ornate decorative elements and carved details",
        "Integration of gardens and outdoor spaces",
        "Emphasis on light and spatial harmony"
      ],
      color: "bg-amber-600"
    },
    {
      icon: Building2,
      period: "Baroque & Classical",
      dates: "1682-1789",
      style: "Monumental Scale",
      features: [
        "Grandiose design and monumental proportions",
        "Formal gardens with geometric layouts",
        "Rich materials and elaborate ornamentation",
        "Symbolic representation of royal power"
      ],
      color: "bg-purple-600"
    },
    {
      icon: Zap,
      period: "Modern Integration",
      dates: "1900-Present",
      style: "Contemporary Elements",
      features: [
        "Technological integration for climate control",
        "Glass pyramid entrance by I.M. Pei",
        "Accessibility improvements for global audiences",
        "Sustainable practices in building operations"
      ],
      color: "bg-primary"
    }
  ];

  return (
    <section id="architectural-evolution" className="py-20 bg-gradient-to-br from-card to-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6 text-secondary">Architectural Evolution</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            The Louvre's architecture represents a fascinating journey through different periods and styles, each reflecting the era's values and technological capabilities.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {architecturalPeriods.map((period, index) => (
            <div
              key={index}
              className={`scroll-fade-in ${isVisible ? 'visible' : ''} bg-card border border-border rounded-lg p-8 hover:shadow-xl transition-all duration-300`}
              style={{ animationDelay: `${index * 200}ms` }}
            >
              <div className="flex items-center mb-6">
                <div className={`${period.color} text-white rounded-full p-3 mr-4`}>
                  <period.icon className="h-8 w-8" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-secondary">{period.period}</h3>
                  <div className="text-primary font-medium">{period.dates}</div>
                  <div className="text-sm text-muted-foreground">{period.style}</div>
                </div>
              </div>
              
              <div className="space-y-3">
                {period.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-start space-x-3">
                    <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                    <p className="text-muted-foreground text-sm leading-relaxed">{feature}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
