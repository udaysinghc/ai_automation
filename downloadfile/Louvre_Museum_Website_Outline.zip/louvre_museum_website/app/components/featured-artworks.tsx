
"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { ChevronLeft, ChevronRight, MapPin, Calendar } from "lucide-react";
import artworksData from "@/public/data/louvre_top25_artworks.json";

export function FeaturedArtworks() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  // Feature the first 6 most famous artworks
  const featuredArtworks = artworksData?.slice(0, 6) ?? [];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById("featured-artworks");
    if (element) {
      observer.observe(element);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % featuredArtworks.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [featuredArtworks.length]);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % featuredArtworks.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + featuredArtworks.length) % featuredArtworks.length);
  };

  if (!featuredArtworks.length) return null;

  return (
    <section id="featured-artworks" className="py-20 bg-gradient-to-br from-card to-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6 text-secondary">Masterpieces of the Collection</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover the world's most celebrated artworks, from Leonardo da Vinci's enigmatic Mona Lisa to ancient treasures spanning millennia.
          </p>
        </div>

        <div className="relative max-w-6xl mx-auto">
          <div className="overflow-hidden rounded-2xl shadow-2xl">
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {featuredArtworks.map((artwork, index) => (
                <div key={index} className="w-full flex-shrink-0">
                  <div className="grid grid-cols-1 lg:grid-cols-2 bg-card">
                    <div className="relative h-96 lg:h-[600px]">
                      <Image
                        src={artwork?.image_url || "https://c8.alamy.com/comp/EATB7Y/classic-greek-architecture-the-philadelphia-museum-of-art-is-among-EATB7Y.jpg"}
                        alt={artwork?.title || "Artwork"}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="p-8 lg:p-12 flex flex-col justify-center">
                      <div className="mb-6">
                        <h3 className="text-3xl font-bold text-secondary mb-2">{artwork?.title}</h3>
                        <p className="text-xl text-primary font-medium mb-4">{artwork?.artist}</p>
                        <div className="flex items-center space-x-4 text-muted-foreground mb-4">
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-4 w-4" />
                            <span>{artwork?.date}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <MapPin className="h-4 w-4" />
                            <span>{artwork?.location?.split(',')[0]}</span>
                          </div>
                        </div>
                      </div>
                      <p className="text-muted-foreground leading-relaxed mb-6">
                        {artwork?.description}
                      </p>
                      <div className="mb-6">
                        <h4 className="font-semibold text-secondary mb-2">Significance</h4>
                        <p className="text-muted-foreground text-sm leading-relaxed">
                          {artwork?.significance}
                        </p>
                      </div>
                      <Link 
                        href={`/artwork/${index}`}
                        className="inline-flex items-center space-x-2 bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors w-fit"
                      >
                        <span>View Details</span>
                        <ChevronRight className="h-4 w-4" />
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={prevSlide}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white text-secondary rounded-full p-2 shadow-lg transition-all duration-200"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>

          <button
            onClick={nextSlide}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white text-secondary rounded-full p-2 shadow-lg transition-all duration-200"
          >
            <ChevronRight className="h-6 w-6" />
          </button>

          <div className="flex justify-center mt-8 space-x-2">
            {featuredArtworks.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full transition-all duration-200 ${
                  index === currentIndex ? 'bg-primary scale-125' : 'bg-muted hover:bg-primary/50'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
