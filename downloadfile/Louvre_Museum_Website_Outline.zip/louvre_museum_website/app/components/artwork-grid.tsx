
"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { Calendar, MapPin, User } from "lucide-react";
import artworksData from "@/public/data/louvre_top25_artworks.json";

export function ArtworkGrid() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById("artwork-grid");
    if (element) {
      observer.observe(element);
    }

    return () => observer.disconnect();
  }, []);

  if (!artworksData) return null;

  return (
    <div id="artwork-grid" className="masonry-grid">
      {artworksData.map((artwork, index) => (
        <Link
          key={index}
          href={`/artwork/${index}`}
          className={`masonry-item scroll-fade-in ${isVisible ? 'visible' : ''} block`}
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <div className="artwork-card group">
            <div className="relative overflow-hidden">
              <div className="aspect-[4/3] relative">
                <Image
                  src={artwork?.image_url || "https://media.timeout.com/images/106015814/image.jpg"}
                  alt={artwork?.title || "Artwork"}
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute bottom-4 left-4 right-4 text-white transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 opacity-0 group-hover:opacity-100">
                <p className="text-sm font-medium">Click to explore</p>
              </div>
            </div>
            
            <div className="p-6">
              <div className="mb-4">
                <h3 className="text-xl font-bold text-secondary mb-2 group-hover:text-primary transition-colors">
                  {artwork?.title}
                </h3>
                <div className="flex items-center space-x-1 text-primary font-medium mb-2">
                  <User className="h-4 w-4" />
                  <span>{artwork?.artist}</span>
                </div>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-3 w-3" />
                    <span>{artwork?.date}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <MapPin className="h-3 w-3" />
                    <span>{artwork?.location?.split(',')[0]}</span>
                  </div>
                </div>
              </div>
              
              <p className="text-muted-foreground text-sm leading-relaxed mb-4 line-clamp-3">
                {artwork?.description}
              </p>
              
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                  {artwork?.medium?.split(' ')[0]}
                </span>
                <span className="text-xs text-primary font-medium">
                  View Details →
                </span>
              </div>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}
