
import { Shield, Wifi, Baby, Utensils, Gift, Camera } from "lucide-react";

export function PracticalInfo() {
  const facilities = [
    {
      icon: Shield,
      title: "Security & Safety",
      description: "Bag checks required at entrance. Large bags and suitcases not permitted. Coat check available.",
      color: "bg-red-100 text-red-600"
    },
    {
      icon: Wifi,
      title: "Digital Services",
      description: "Free WiFi throughout the museum. Mobile app available with interactive maps and audio guides.",
      color: "bg-blue-100 text-blue-600"
    },
    {
      icon: Baby,
      title: "Family Facilities",
      description: "Baby strollers available. Family workshops and children's trails. Changing rooms on each floor.",
      color: "bg-green-100 text-green-600"
    },
    {
      icon: Utensils,
      title: "Dining Options",
      description: "Multiple cafes and restaurants. Angelina tea room. Picnic areas in Tuileries Garden nearby.",
      color: "bg-orange-100 text-orange-600"
    },
    {
      icon: Gift,
      title: "Shopping",
      description: "Museum store with art books, reproductions, and gifts. Multiple locations throughout the museum.",
      color: "bg-purple-100 text-purple-600"
    },
    {
      icon: Camera,
      title: "Photography",
      description: "Photography allowed without flash. No selfie sticks. Tripods require special permission.",
      color: "bg-teal-100 text-teal-600"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-card to-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6 text-secondary">Practical Information</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Additional services and facilities to enhance your Louvre experience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {facilities.map((facility, index) => (
            <div key={index} className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition-shadow">
              <div className={`${facility.color} rounded-full p-3 w-fit mb-4`}>
                <facility.icon className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-secondary mb-3">{facility.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{facility.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-card border border-border rounded-lg p-8">
          <h3 className="text-2xl font-bold text-secondary mb-6">Accessibility</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-lg font-semibold text-secondary mb-3">Physical Accessibility</h4>
              <ul className="text-muted-foreground space-y-2">
                <li>• Wheelchair accessible entrances and elevators</li>
                <li>• Wheelchairs available for loan (subject to availability)</li>
                <li>• Audio guides with visual descriptions</li>
                <li>• Tactile tours for visually impaired visitors</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-secondary mb-3">Additional Services</h4>
              <ul className="text-muted-foreground space-y-2">
                <li>• Sign language interpretation on request</li>
                <li>• Large print materials available</li>
                <li>• Accessible restrooms on all floors</li>
                <li>• Priority access for visitors with disabilities</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
