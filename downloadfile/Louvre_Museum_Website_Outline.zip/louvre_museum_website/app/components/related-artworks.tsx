
"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { ChevronRight } from "lucide-react";
import artworksData from "@/public/data/louvre_top25_artworks.json";

interface RelatedArtworksProps {
  currentArtworkIndex: number;
}

export function RelatedArtworks({ currentArtworkIndex }: RelatedArtworksProps) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  if (!artworksData) return null;

  // Get 4 related artworks (excluding current one)
  const relatedArtworks = artworksData
    .filter((_, index) => index !== currentArtworkIndex)
    .slice(0, 4);

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="mb-12">
        <h2 className="text-3xl font-bold text-secondary mb-4">Related Masterpieces</h2>
        <p className="text-muted-foreground text-lg">
          Discover more treasures from the Louvre's extraordinary collection
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {relatedArtworks.map((artwork, index) => {
          const actualIndex = artworksData.findIndex(a => a.title === artwork.title);
          return (
            <Link
              key={actualIndex}
              href={`/artwork/${actualIndex}`}
              className="group block"
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              <div className="artwork-card">
                <div className="relative overflow-hidden">
                  <div className="aspect-[4/3] relative">
                    <Image
                      src={artwork?.image_url || "https://d1nn9x4fgzyvn4.cloudfront.net/migration-slide-image/SC172672_4x3.jpg"}
                      alt={artwork?.title || "Artwork"}
                      fill
                      className="object-cover transition-transform duration-300 group-hover:scale-105"
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                    />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <div className="absolute bottom-4 left-4 right-4 text-white transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 opacity-0 group-hover:opacity-100">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium">View Details</span>
                      <ChevronRight className="h-4 w-4" />
                    </div>
                  </div>
                </div>
                
                <div className="p-4">
                  <h3 className="font-semibold text-secondary mb-2 group-hover:text-primary transition-colors">
                    {artwork?.title}
                  </h3>
                  <p className="text-sm text-primary font-medium mb-2">{artwork?.artist}</p>
                  <p className="text-xs text-muted-foreground">{artwork?.date}</p>
                </div>
              </div>
            </Link>
          );
        })}
      </div>

      <div className="mt-12 text-center">
        <Link 
          href="/gallery"
          className="inline-flex items-center space-x-2 bg-primary text-primary-foreground px-8 py-4 rounded-lg text-lg font-medium hover:bg-primary/90 transition-all duration-300 hover:shadow-lg"
        >
          <span>View All Artworks</span>
          <ChevronRight className="h-5 w-5" />
        </Link>
      </div>
    </div>
  );
}
