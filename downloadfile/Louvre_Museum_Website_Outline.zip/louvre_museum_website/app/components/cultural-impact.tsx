
"use client";

import { useEffect, useState } from "react";
import { Globe, GraduationCap, Heart, Landmark } from "lucide-react";

export function CulturalImpact() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById("cultural-impact");
    if (element) {
      observer.observe(element);
    }

    return () => observer.disconnect();
  }, []);

  const impacts = [
    {
      icon: Landmark,
      title: "Pioneering Museum Concept",
      description: "The Louvre established fundamental principles that define modern museums worldwide, including public accessibility as a fundamental right, educational mission beyond exhibition, and professional curatorial standards.",
      stats: "First major public museum (1793)"
    },
    {
      icon: Globe,
      title: "Global Influence",
      description: "The Louvre model has inspired major institutions worldwide, from the Metropolitan Museum of Art in New York to the British Museum in London, shaping how cultural institutions serve the public.",
      stats: "Influenced 100+ major museums globally"
    },
    {
      icon: GraduationCap,
      title: "Educational Legacy",
      description: "Through international exhibitions, educational partnerships, and cultural exchanges, the Louvre has become a cornerstone of art education and cultural literacy across the globe.",
      stats: "9 million annual visitors educated"
    },
    {
      icon: Heart,
      title: "Cultural Diplomacy",
      description: "The Louvre serves as a powerful tool of French cultural diplomacy, promoting cultural tourism, international understanding, and serving as a symbol of European cultural heritage.",
      stats: "Symbol of cultural unity"
    }
  ];

  return (
    <section id="cultural-impact" className="py-20 bg-secondary text-secondary-foreground">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6 text-primary">Cultural Impact & Global Influence</h2>
          <p className="text-xl text-secondary-foreground/80 max-w-3xl mx-auto">
            The Louvre's influence extends far beyond its walls, shaping how the world understands art, culture, and the role of museums in society.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {impacts.map((impact, index) => (
            <div
              key={index}
              className={`scroll-fade-in ${isVisible ? 'visible' : ''} bg-secondary-foreground/5 border border-secondary-foreground/10 rounded-lg p-8 hover:bg-secondary-foreground/10 transition-all duration-300`}
              style={{ animationDelay: `${index * 200}ms` }}
            >
              <div className="flex items-start space-x-4">
                <div className="bg-primary text-primary-foreground rounded-full p-3 flex-shrink-0">
                  <impact.icon className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-3">{impact.title}</h3>
                  <p className="text-secondary-foreground/80 leading-relaxed mb-4">{impact.description}</p>
                  <div className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium inline-block">
                    {impact.stats}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-secondary-foreground/5 border border-secondary-foreground/10 rounded-lg p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold mb-4 text-primary">A Living Legacy</h3>
            <p className="text-secondary-foreground/80 leading-relaxed">
              The Louvre's story is far from over. As it continues to acquire new works, develop innovative programming, and adapt to changing global needs, it remains a living institution that honors its past while embracing the future. In doing so, it ensures that the artistic treasures of humanity will continue to inspire, educate, and unite people from all corners of the world for generations to come.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
