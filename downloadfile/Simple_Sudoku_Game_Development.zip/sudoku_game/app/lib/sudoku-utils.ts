
type CellValue = number | null;
type SudokuGrid = CellValue[][];

// Pre-defined medium difficulty Sudoku puzzles
const PUZZLES: SudokuGrid[] = [
  [
    [5, 3, null, null, 7, null, null, null, null],
    [6, null, null, 1, 9, 5, null, null, null],
    [null, 9, 8, null, null, null, null, 6, null],
    [8, null, null, null, 6, null, null, null, 3],
    [4, null, null, 8, null, 3, null, null, 1],
    [7, null, null, null, 2, null, null, null, 6],
    [null, 6, null, null, null, null, 2, 8, null],
    [null, null, null, 4, 1, 9, null, null, 5],
    [null, null, null, null, 8, null, null, 7, 9]
  ],
  [
    [null, null, null, 6, null, null, 4, null, null],
    [7, null, null, null, null, 3, 6, null, null],
    [null, null, null, null, 9, 1, null, 8, null],
    [null, null, null, null, null, null, null, null, null],
    [null, 5, null, 1, 8, null, null, null, 3],
    [null, null, null, 3, null, 6, null, 4, 5],
    [null, 4, null, 2, null, null, null, 6, null],
    [9, null, 3, null, null, null, null, null, null],
    [null, 2, null, null, null, null, 1, null, null]
  ],
  [
    [null, null, null, null, null, null, 6, 8, null],
    [null, null, null, null, null, 3, null, null, null],
    [7, null, null, 6, null, null, null, null, 9],
    [null, 5, null, null, null, 7, null, null, null],
    [null, null, null, null, 4, 5, 7, null, null],
    [null, null, null, 1, null, null, null, 3, null],
    [null, null, 1, null, null, null, null, 6, 8],
    [null, null, 8, 5, null, null, null, 1, null],
    [null, 9, null, null, null, null, 4, null, null]
  ]
];

export function generateNewPuzzle(): SudokuGrid {
  const randomIndex = Math.floor(Math.random() * PUZZLES.length);
  return PUZZLES[randomIndex]?.map(row => [...row]) ?? PUZZLES[0]?.map(row => [...row]) ?? [];
}

export function isValidMove(grid: SudokuGrid, row: number, col: number, value: number): boolean {
  if (!grid?.[row]) return false;

  // Check row
  for (let c = 0; c < 9; c++) {
    if (c !== col && grid[row]?.[c] === value) {
      return false;
    }
  }

  // Check column
  for (let r = 0; r < 9; r++) {
    if (r !== row && grid[r]?.[col] === value) {
      return false;
    }
  }

  // Check 3x3 box
  const boxRow = Math.floor(row / 3) * 3;
  const boxCol = Math.floor(col / 3) * 3;
  
  for (let r = boxRow; r < boxRow + 3; r++) {
    for (let c = boxCol; c < boxCol + 3; c++) {
      if ((r !== row || c !== col) && grid[r]?.[c] === value) {
        return false;
      }
    }
  }

  return true;
}

export function validateSudoku(grid: SudokuGrid): boolean {
  if (!grid || grid.length !== 9) return false;

  // Check if all cells are filled
  for (let row = 0; row < 9; row++) {
    for (let col = 0; col < 9; col++) {
      const value = grid[row]?.[col];
      if (!value || value < 1 || value > 9) {
        return false;
      }
    }
  }

  // Check rows
  for (let row = 0; row < 9; row++) {
    const seen = new Set<number>();
    for (let col = 0; col < 9; col++) {
      const value = grid[row]?.[col];
      if (!value || seen.has(value)) {
        return false;
      }
      seen.add(value);
    }
  }

  // Check columns
  for (let col = 0; col < 9; col++) {
    const seen = new Set<number>();
    for (let row = 0; row < 9; row++) {
      const value = grid[row]?.[col];
      if (!value || seen.has(value)) {
        return false;
      }
      seen.add(value);
    }
  }

  // Check 3x3 boxes
  for (let boxRow = 0; boxRow < 3; boxRow++) {
    for (let boxCol = 0; boxCol < 3; boxCol++) {
      const seen = new Set<number>();
      for (let row = boxRow * 3; row < (boxRow + 1) * 3; row++) {
        for (let col = boxCol * 3; col < (boxCol + 1) * 3; col++) {
          const value = grid[row]?.[col];
          if (!value || seen.has(value)) {
            return false;
          }
          seen.add(value);
        }
      }
    }
  }

  return true;
}
