
export interface Artwork {
  title: string;
  artist: string;
  date: string;
  medium: string;
  dimensions: string;
  description: string;
  significance: string;
  location: string;
  image_url: string;
}

export interface HistoricalPeriod {
  period: string;
  dates: string;
  description: string;
  significance: string;
}

export interface MuseumSection {
  title: string;
  description: string;
  highlights: string[];
}
