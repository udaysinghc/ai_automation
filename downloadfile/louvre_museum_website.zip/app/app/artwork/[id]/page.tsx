
import { ArtworkDetail } from "@/components/artwork-detail";
import { RelatedArtworks } from "@/components/related-artworks";
import { notFound } from "next/navigation";
import artworksData from "@/public/data/louvre_top25_artworks.json";

export const dynamic = "force-static";

export async function generateStaticParams() {
  return artworksData.map((artwork, index) => ({
    id: index.toString(),
  }));
}

interface ArtworkPageProps {
  params: {
    id: string;
  };
}

export default function ArtworkPage({ params }: ArtworkPageProps) {
  const artworkIndex = parseInt(params?.id ?? "0");
  const artwork = artworksData?.[artworkIndex];

  if (!artwork) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background">
      <ArtworkDetail artwork={artwork} />
      <RelatedArtworks currentArtworkIndex={artworkIndex} />
    </div>
  );
}
