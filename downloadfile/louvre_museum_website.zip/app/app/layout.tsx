
import type { Metadata } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/theme-provider";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

const inter = Inter({ subsets: ["latin"] });
const playfair = Playfair_Display({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Louvre Museum - From Medieval Fortress to Global Cultural Icon",
  description: "Explore the magnificent history and world-renowned art collection of the Louvre Museum in Paris. Discover masterpieces from Leonardo da Vinci, ancient sculptures, and treasures spanning 5,000 years of human creativity.",
  keywords: "Louvre Museum, Paris, art, history, Mona Lisa, Leonardo da Vinci, masterpieces, culture",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.className} antialiased`}>
        <ThemeProvider enableSystem={false} attribute="class" defaultTheme="light">
          <div className="min-h-screen flex flex-col">
            <Header />
            <main className="flex-1">
              {children}
            </main>
            <Footer />
          </div>
        </ThemeProvider>
      </body>
    </html>
  );
}
