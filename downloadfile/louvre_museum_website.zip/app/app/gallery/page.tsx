
import { ArtworkGrid } from "@/components/artwork-grid";
import { GalleryHeader } from "@/components/gallery-header";
import { GalleryFilters } from "@/components/gallery-filters";

export default function Gallery() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background">
      <GalleryHeader />
      <div className="container mx-auto px-4 py-8">
        <GalleryFilters />
        <ArtworkGrid />
      </div>
    </div>
  );
}
