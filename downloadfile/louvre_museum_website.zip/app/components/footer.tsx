
import { Crown, MapPin, Clock, Phone } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-secondary text-secondary-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Crown className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Louvre Museum</span>
            </div>
            <p className="text-secondary-foreground/80">
              From medieval fortress to global cultural icon, the Louvre houses humanity's greatest artistic treasures.
            </p>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-primary">Visit Information</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4 text-primary" />
                <span className="text-sm">Rue de Rivoli, 75001 Paris, France</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4 text-primary" />
                <span className="text-sm">Open daily 9:00 AM - 6:00 PM</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-primary" />
                <span className="text-sm">+33 1 40 20 50 50</span>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-primary">Quick Links</h3>
            <div className="space-y-2">
              <div><a href="/" className="text-sm hover:text-primary transition-colors">Home</a></div>
              <div><a href="/gallery" className="text-sm hover:text-primary transition-colors">Gallery</a></div>
              <div><a href="/about" className="text-sm hover:text-primary transition-colors">About</a></div>
              <div><a href="/visit" className="text-sm hover:text-primary transition-colors">Visit</a></div>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-secondary-foreground/20 text-center">
          <p className="text-sm text-secondary-foreground/60">
            © 2024 Louvre Museum. A celebration of art, history, and human creativity.
          </p>
        </div>
      </div>
    </footer>
  );
}
