
"use client";

import { ChevronRight, Camera, Book, Map } from "lucide-react";
import Link from "next/link";

export function CallToAction() {
  const actions = [
    {
      icon: Camera,
      title: "Explore the Gallery",
      description: "Discover all 25 masterpieces in our comprehensive collection",
      href: "/gallery",
      color: "bg-primary hover:bg-primary/90"
    },
    {
      icon: Book,
      title: "Learn the History",
      description: "Dive deep into 800 years of fascinating museum evolution",
      href: "/about",
      color: "bg-secondary hover:bg-secondary/90"
    },
    {
      icon: Map,
      title: "Plan Your Visit",
      description: "Get practical information for your Louvre experience",
      href: "/visit",
      color: "bg-blue-600 hover:bg-blue-700"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-background via-card to-background parchment-texture">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6 text-secondary">Begin Your Journey</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Whether you're planning a visit or exploring from home, discover the treasures that have captivated humanity for centuries.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {actions.map((action, index) => (
            <Link
              key={index}
              href={action.href}
              className="group block"
            >
              <div className="bg-card border border-border rounded-lg p-8 hover:shadow-xl transition-all duration-300 hover:scale-105 text-center">
                <div className="flex justify-center mb-6">
                  <div className={`${action.color} text-white rounded-full p-4 group-hover:scale-110 transition-transform duration-300`}>
                    <action.icon className="h-8 w-8" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold mb-4 text-secondary">{action.title}</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">{action.description}</p>
                <div className="flex items-center justify-center space-x-2 text-primary font-medium group-hover:text-primary/80 transition-colors">
                  <span>Get Started</span>
                  <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-card border border-border rounded-lg p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold mb-4 text-secondary">Experience the World's Greatest Museum</h3>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              From Leonardo da Vinci's enigmatic Mona Lisa to ancient treasures that predate Christ, the Louvre offers an unparalleled journey through human creativity and achievement.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                href="/gallery"
                className="inline-flex items-center space-x-2 bg-primary text-primary-foreground px-8 py-4 rounded-lg text-lg font-medium hover:bg-primary/90 transition-all duration-300 hover:shadow-lg"
              >
                <Camera className="h-5 w-5" />
                <span>View All Artworks</span>
              </Link>
              <Link 
                href="/about"
                className="inline-flex items-center space-x-2 bg-secondary text-secondary-foreground px-8 py-4 rounded-lg text-lg font-medium hover:bg-secondary/90 transition-all duration-300 hover:shadow-lg"
              >
                <Book className="h-5 w-5" />
                <span>Read Full History</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
