
"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { ChevronRight, Users, Calendar, MapPin } from "lucide-react";
import Link from "next/link";

export function Hero() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <Image
          src="https://i.ytimg.com/vi/LRAy0UzjpCw/maxresdefault.jpg"
          alt="Louvre Museum pyramid at sunset"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-br from-secondary/80 via-secondary/60 to-primary/40" />
      </div>
      
      <div className="relative z-10 text-center text-white px-4 max-w-4xl">
        <div className={`transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-shadow">
            The Louvre Museum
          </h1>
          <p className="text-xl md:text-2xl mb-8 font-light text-shadow">
            From Medieval Fortress to Global Cultural Icon
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-primary" />
              <span>9 million annual visitors</span>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-primary" />
              <span>800+ years of history</span>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="h-5 w-5 text-primary" />
              <span>Paris, France</span>
            </div>
          </div>
          <Link 
            href="/gallery" 
            className="inline-flex items-center space-x-2 bg-primary text-primary-foreground px-8 py-4 rounded-lg text-lg font-medium hover:bg-primary/90 transition-all duration-300 hover:shadow-lg"
          >
            <span>Explore the Collection</span>
            <ChevronRight className="h-5 w-5" />
          </Link>
        </div>
      </div>
    </section>
  );
}
