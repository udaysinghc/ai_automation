
"use client";

import { ArrowLeft, Image as ImageIcon, Clock, MapPin } from "lucide-react";
import Link from "next/link";

export function GalleryHeader() {
  return (
    <div className="bg-gradient-to-r from-secondary to-primary text-white py-16">
      <div className="container mx-auto px-4">
        <div className="flex items-center mb-6">
          <Link 
            href="/"
            className="flex items-center space-x-2 text-white/80 hover:text-white transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Home</span>
          </Link>
        </div>
        
        <div className="max-w-4xl">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-shadow">
            The Collection
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-white/90 leading-relaxed">
            Explore 25 masterpieces from the world's most celebrated museum. From ancient civilizations to Renaissance masters, discover the treasures that have shaped human culture.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center space-x-3 bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <ImageIcon className="h-8 w-8 text-primary" />
              <div>
                <div className="text-2xl font-bold">25</div>
                <div className="text-sm text-white/80">Masterpieces</div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <Clock className="h-8 w-8 text-primary" />
              <div>
                <div className="text-2xl font-bold">5,000+</div>
                <div className="text-sm text-white/80">Years of Art</div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <MapPin className="h-8 w-8 text-primary" />
              <div>
                <div className="text-2xl font-bold">8</div>
                <div className="text-sm text-white/80">Departments</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
