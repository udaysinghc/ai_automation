
"use client";

import { useEffect, useState } from "react";
import { Users, Image as ImageIcon, Calendar, MapPin } from "lucide-react";

export function MuseumStats() {
  const [isVisible, setIsVisible] = useState(false);
  const [animatedStats, setAnimatedStats] = useState({
    visitors: 0,
    artworks: 0,
    years: 0,
    space: 0
  });

  const finalStats = {
    visitors: 9,
    artworks: 500000,
    years: 800,
    space: 72735
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById("museum-stats");
    if (element) {
      observer.observe(element);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (isVisible) {
      const duration = 2000;
      const startTime = Date.now();

      const animate = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);

        const easeOutQuart = (t: number) => 1 - Math.pow(1 - t, 4);
        const easedProgress = easeOutQuart(progress);

        setAnimatedStats({
          visitors: Math.floor(finalStats.visitors * easedProgress),
          artworks: Math.floor(finalStats.artworks * easedProgress),
          years: Math.floor(finalStats.years * easedProgress),
          space: Math.floor(finalStats.space * easedProgress)
        });

        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };

      animate();
    }
  }, [isVisible]);

  const stats = [
    {
      icon: Users,
      value: animatedStats.visitors,
      unit: "M",
      label: "Annual Visitors",
      description: "Making it the world's most-visited museum"
    },
    {
      icon: ImageIcon,
      value: animatedStats.artworks,
      unit: "",
      label: "Artworks",
      description: "Spanning 5,000 years of human creativity"
    },
    {
      icon: Calendar,
      value: animatedStats.years,
      unit: "+",
      label: "Years of History",
      description: "From medieval fortress to global icon"
    },
    {
      icon: MapPin,
      value: animatedStats.space,
      unit: "m²",
      label: "Exhibition Space",
      description: "Across three magnificent wings"
    }
  ];

  return (
    <section id="museum-stats" className="py-20 bg-secondary text-secondary-foreground">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6 text-primary">By the Numbers</h2>
          <p className="text-xl text-secondary-foreground/80 max-w-3xl mx-auto">
            The Louvre's scale and significance in numbers - a testament to humanity's greatest artistic achievements.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className={`text-center scroll-fade-in ${isVisible ? 'visible' : ''} bg-secondary-foreground/5 rounded-lg p-6 hover:bg-secondary-foreground/10 transition-all duration-300`}
              style={{ animationDelay: `${index * 200}ms` }}
            >
              <div className="flex justify-center mb-4">
                <stat.icon className="h-12 w-12 text-primary" />
              </div>
              <div className="mb-2">
                <span className="text-4xl font-bold text-primary">
                  {stat.value?.toLocaleString()}
                </span>
                <span className="text-2xl font-bold text-primary">{stat.unit}</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">{stat.label}</h3>
              <p className="text-secondary-foreground/70 text-sm">{stat.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
