
"use client";

import { useState } from "react";
import { Search, Filter, Grid, List } from "lucide-react";

export function GalleryFilters() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPeriod, setSelectedPeriod] = useState("all");
  const [selectedMedium, setSelectedMedium] = useState("all");
  const [viewMode, setViewMode] = useState("grid");

  const periods = ["all", "ancient", "medieval", "renaissance", "baroque", "modern"];
  const mediums = ["all", "painting", "sculpture", "stone", "marble"];

  return (
    <div className="mb-8">
      <div className="bg-card border border-border rounded-lg p-6 shadow-lg">
        <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
          <div className="flex flex-col sm:flex-row gap-4 flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search artworks..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent bg-background"
              />
            </div>
            
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent bg-background"
            >
              {periods.map(period => (
                <option key={period} value={period}>
                  {period === "all" ? "All Periods" : period.charAt(0).toUpperCase() + period.slice(1)}
                </option>
              ))}
            </select>
            
            <select
              value={selectedMedium}
              onChange={(e) => setSelectedMedium(e.target.value)}
              className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent bg-background"
            >
              {mediums.map(medium => (
                <option key={medium} value={medium}>
                  {medium === "all" ? "All Mediums" : medium.charAt(0).toUpperCase() + medium.slice(1)}
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode("grid")}
              className={`p-2 rounded-lg transition-colors ${
                viewMode === "grid" 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-background hover:bg-muted"
              }`}
            >
              <Grid className="h-4 w-4" />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`p-2 rounded-lg transition-colors ${
                viewMode === "list" 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-background hover:bg-muted"
              }`}
            >
              <List className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
