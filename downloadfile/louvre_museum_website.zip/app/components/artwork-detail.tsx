
"use client";

import { ArrowLeft, Calendar, MapPin, Ruler, Palette, Info } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

interface Artwork {
  title: string;
  artist: string;
  date: string;
  medium: string;
  dimensions: string;
  description: string;
  significance: string;
  location: string;
  image_url: string;
}

interface ArtworkDetailProps {
  artwork: Artwork;
}

export function ArtworkDetail({ artwork }: ArtworkDetailProps) {
  if (!artwork) return null;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link 
          href="/gallery"
          className="flex items-center space-x-2 text-muted-foreground hover:text-primary transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Gallery</span>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="space-y-6">
          <div className="aspect-[4/3] relative rounded-lg overflow-hidden shadow-2xl">
            <Image
              src={artwork.image_url || "https://media.timeout.com/images/106015814/image.jpg"}
              alt={artwork.title}
              fill
              className="object-cover"
              priority
            />
          </div>
          
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-secondary mb-4 flex items-center space-x-2">
              <Palette className="h-5 w-5 text-primary" />
              <span>Technical Details</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium text-secondary mb-1">Medium</h4>
                <p className="text-muted-foreground text-sm">{artwork.medium}</p>
              </div>
              <div>
                <h4 className="font-medium text-secondary mb-1">Dimensions</h4>
                <p className="text-muted-foreground text-sm">{artwork.dimensions}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div>
            <h1 className="text-4xl font-bold text-secondary mb-4">{artwork.title}</h1>
            <div className="space-y-3">
              <div className="flex items-center space-x-2 text-primary text-xl font-medium">
                <span>{artwork.artist}</span>
              </div>
              <div className="flex items-center space-x-6 text-muted-foreground">
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4" />
                  <span>{artwork.date}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4" />
                  <span>{artwork.location}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-xl font-semibold text-secondary mb-4">Description</h3>
            <p className="text-muted-foreground leading-relaxed">{artwork.description}</p>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-xl font-semibold text-secondary mb-4 flex items-center space-x-2">
              <Info className="h-5 w-5 text-primary" />
              <span>Historical Significance</span>
            </h3>
            <p className="text-muted-foreground leading-relaxed">{artwork.significance}</p>
          </div>

          <div className="bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/20 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-secondary mb-4">Visit This Artwork</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4 text-primary" />
                <span className="text-muted-foreground">Location: {artwork.location}</span>
              </div>
              <p className="text-sm text-muted-foreground">
                This masterpiece is permanently housed in the Louvre Museum in Paris, France. 
                Plan your visit to experience its grandeur in person.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
