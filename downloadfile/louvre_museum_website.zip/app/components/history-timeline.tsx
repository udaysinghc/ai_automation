
"use client";

import { useState, useEffect } from "react";
import { Castle, Crown, Palette, Building, Sword, BookOpen, Users, Globe } from "lucide-react";

export function HistoryTimeline() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById("history-timeline");
    if (element) {
      observer.observe(element);
    }

    return () => observer.disconnect();
  }, []);

  const timelineEvents = [
    {
      icon: Castle,
      year: "1190",
      period: "Medieval Fortress",
      title: "Birth of the Louvre",
      description: "King Philip II Augustus orders construction of a fortress on the western front of Paris's city wall. The original structure features thick curtain walls, ten defensive towers, and a large moat filled with water from the Seine.",
      color: "bg-slate-600"
    },
    {
      icon: Crown,
      year: "1364",
      period: "Royal Residence",
      title: "Charles V's Transformation",
      description: "King Charles V converts the fortress into a comfortable royal residence with ornate rooftops, carved windows, spiral staircases, and a grand garden for royal leisure.",
      color: "bg-amber-600"
    },
    {
      icon: Palette,
      year: "1528",
      period: "Renaissance Revolution",
      title: "Francis I's Cultural Vision",
      description: "Francis I demolishes the medieval Grand Tower and commissions Pierre Lescot to design the new palace in Italian Renaissance style. He acquires Leonardo da Vinci's Mona Lisa and hosts the master artist himself.",
      color: "bg-purple-600"
    },
    {
      icon: Building,
      year: "1682",
      period: "Cultural Center",
      title: "Move to Versailles",
      description: "Louis XIV relocates the royal court to Versailles, transforming the Louvre into a cultural and artistic center housing royal academies and attracting artists, craftsmen, and intellectuals.",
      color: "bg-blue-600"
    },
    {
      icon: BookOpen,
      year: "1793",
      period: "Public Museum",
      title: "Revolutionary Opening",
      description: "The Louvre opens as the Muséum Central des Arts de la République on August 10, 1793, displaying 537 paintings to the public for the first time, embodying revolutionary ideals of cultural democratization.",
      color: "bg-red-600"
    },
    {
      icon: Sword,
      year: "1803",
      period: "Imperial Grandeur",
      title: "Musée Napoléon",
      description: "Napoleon renames the museum and systematically acquires approximately 5,000 artworks from conquered territories, adding masterpieces like the Winged Victory of Samothrace and Venus de Milo.",
      color: "bg-emerald-600"
    },
    {
      icon: Users,
      year: "1852",
      period: "Modern Expansion",
      title: "Napoleon III's Renovation",
      description: "Napoleon III initiates the most ambitious expansion since the original construction, creating the Cour Napoléon courtyard, adding the Richelieu Wing, and introducing modern materials.",
      color: "bg-indigo-600"
    },
    {
      icon: Globe,
      year: "1989",
      period: "Global Icon",
      title: "The Glass Pyramid",
      description: "I.M. Pei's iconic glass pyramid opens as the new entrance, symbolizing the fusion of tradition and modernity. The Louvre becomes the world's most-visited museum with 9 million annual visitors.",
      color: "bg-primary"
    }
  ];

  return (
    <section id="history-timeline" className="py-20 container mx-auto px-4">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold mb-6 text-secondary">Eight Centuries of Evolution</h2>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Follow the remarkable transformation of the Louvre from medieval fortress to the world's most celebrated museum.
        </p>
      </div>

      <div className="relative">
        <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 w-1 bg-gradient-to-b from-primary to-secondary h-full"></div>
        
        <div className="space-y-12">
          {timelineEvents.map((event, index) => (
            <div
              key={index}
              className={`flex items-center ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'} scroll-fade-in ${isVisible ? 'visible' : ''}`}
              style={{ animationDelay: `${index * 200}ms` }}
            >
              <div className={`flex-1 ${index % 2 === 0 ? 'md:pr-8' : 'md:pl-8'}`}>
                <div className="bg-card border border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-all duration-300">
                  <div className="flex items-center mb-4">
                    <div className={`${event.color} text-white rounded-full p-3 mr-4`}>
                      <event.icon className="h-6 w-6" />
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-primary">{event.year}</div>
                      <div className="text-sm text-muted-foreground">{event.period}</div>
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-secondary mb-3">{event.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{event.description}</p>
                </div>
              </div>
              
              <div className="relative flex-shrink-0 mx-4 md:mx-0">
                <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 w-4 h-4 bg-primary rounded-full border-4 border-background"></div>
              </div>
              
              <div className="flex-1 hidden md:block"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
