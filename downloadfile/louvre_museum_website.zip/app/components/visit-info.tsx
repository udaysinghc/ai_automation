
"use client";

import { useState } from "react";
import { MapPin, Clock, CreditCard, Users, Info, Star } from "lucide-react";

export function VisitInfo() {
  const [activeTab, setActiveTab] = useState("hours");

  const tabs = [
    { id: "hours", label: "Hours & Admission", icon: Clock },
    { id: "location", label: "Location & Access", icon: MapPin },
    { id: "tickets", label: "Tickets & Prices", icon: CreditCard },
    { id: "groups", label: "Groups & Tours", icon: Users },
    { id: "tips", label: "Visitor Tips", icon: Star }
  ];

  return (
    <section className="py-20 container mx-auto px-4">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold mb-6 text-secondary">Plan Your Visit</h2>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Everything you need to know for an unforgettable experience at the world's most visited museum.
        </p>
      </div>

      <div className="max-w-6xl mx-auto">
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                activeTab === tab.id
                  ? "bg-primary text-primary-foreground shadow-lg"
                  : "bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground"
              }`}
            >
              <tab.icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        <div className="bg-card border border-border rounded-lg p-8 shadow-lg">
          {activeTab === "hours" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-2xl font-bold text-secondary mb-4">Opening Hours</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="font-medium">Monday</span>
                      <span className="text-muted-foreground">9:00 AM - 6:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Tuesday</span>
                      <span className="text-red-600">Closed</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Wednesday - Sunday</span>
                      <span className="text-muted-foreground">9:00 AM - 6:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Friday (evening)</span>
                      <span className="text-muted-foreground">9:00 AM - 9:45 PM</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-secondary mb-4">Admission Prices</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="font-medium">Adults</span>
                      <span className="text-primary font-bold">€15</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Under 18</span>
                      <span className="text-green-600 font-bold">Free</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">EU residents under 26</span>
                      <span className="text-green-600 font-bold">Free</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">First Friday evening</span>
                      <span className="text-green-600 font-bold">Free</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "location" && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-secondary mb-4">Location & Transportation</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-lg font-semibold text-secondary mb-3">Address</h4>
                  <p className="text-muted-foreground mb-4">
                    Rue de Rivoli<br />
                    75001 Paris, France
                  </p>
                  <h4 className="text-lg font-semibold text-secondary mb-3">Metro Stations</h4>
                  <ul className="text-muted-foreground space-y-1">
                    <li>• Palais Royal - Musée du Louvre (Lines 1, 7)</li>
                    <li>• Louvre - Rivoli (Line 1)</li>
                    <li>• Tuileries (Line 1)</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-secondary mb-3">By Car</h4>
                  <p className="text-muted-foreground mb-4">
                    Limited parking available at Carrousel du Louvre underground parking garage.
                  </p>
                  <h4 className="text-lg font-semibold text-secondary mb-3">Airport Access</h4>
                  <ul className="text-muted-foreground space-y-1">
                    <li>• Charles de Gaulle: RER B to Châtelet, then Metro Line 1</li>
                    <li>• Orly: Orlyval to Antony, then RER B to Châtelet</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {activeTab === "tickets" && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-secondary mb-4">Tickets & Reservations</h3>
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
                <div className="flex items-center space-x-2 mb-2">
                  <Info className="h-5 w-5 text-amber-600" />
                  <span className="font-medium text-amber-800">Advance Booking Recommended</span>
                </div>
                <p className="text-amber-700 text-sm">
                  Time slots are required for all visitors. Book online to guarantee your preferred time.
                </p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-lg font-semibold text-secondary mb-3">Ticket Types</h4>
                  <div className="space-y-4">
                    <div className="border border-border rounded-lg p-4">
                      <h5 className="font-medium text-secondary">Standard Admission</h5>
                      <p className="text-sm text-muted-foreground">Access to permanent collections</p>
                      <p className="text-primary font-bold">€15</p>
                    </div>
                    <div className="border border-border rounded-lg p-4">
                      <h5 className="font-medium text-secondary">Louvre + Exhibitions</h5>
                      <p className="text-sm text-muted-foreground">Includes temporary exhibitions</p>
                      <p className="text-primary font-bold">€20</p>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-secondary mb-3">Special Offers</h4>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Free first Friday of each month (evening)</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Paris Museum Pass accepted</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Group discounts available</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "groups" && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-secondary mb-4">Groups & Guided Tours</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-lg font-semibold text-secondary mb-3">Group Visits</h4>
                  <p className="text-muted-foreground mb-4">
                    Groups of 7 or more people must book in advance and are eligible for reduced rates.
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Group rate (7-25 people)</span>
                      <span className="font-medium">€11 per person</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Large groups (25+ people)</span>
                      <span className="font-medium">€9 per person</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-secondary mb-3">Guided Tours</h4>
                  <div className="space-y-3">
                    <div className="border border-border rounded-lg p-3">
                      <h5 className="font-medium text-secondary">Highlights Tour</h5>
                      <p className="text-sm text-muted-foreground">1.5 hours • Most famous works</p>
                      <p className="text-sm text-primary font-medium">€39 per person</p>
                    </div>
                    <div className="border border-border rounded-lg p-3">
                      <h5 className="font-medium text-secondary">Masterpieces Tour</h5>
                      <p className="text-sm text-muted-foreground">2 hours • In-depth exploration</p>
                      <p className="text-sm text-primary font-medium">€49 per person</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "tips" && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-secondary mb-4">Visitor Tips</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-lg font-semibold text-secondary mb-3">Best Times to Visit</h4>
                  <ul className="text-muted-foreground space-y-2">
                    <li>• Early morning (9:00-10:30 AM) for smaller crowds</li>
                    <li>• Wednesday or Friday evenings for extended hours</li>
                    <li>• Avoid Tuesday (museum closed)</li>
                    <li>• Skip first Sunday of each month (free but crowded)</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-secondary mb-3">What to Bring</h4>
                  <ul className="text-muted-foreground space-y-2">
                    <li>• Comfortable walking shoes</li>
                    <li>• Valid ID for reduced rates</li>
                    <li>• Camera (flash photography not allowed)</li>
                    <li>• Water bottle (staying hydrated is important)</li>
                  </ul>
                </div>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-semibold text-blue-800 mb-2">Must-See Highlights</h4>
                <p className="text-blue-700 text-sm">
                  Don't miss the Mona Lisa, Venus de Milo, and Winged Victory of Samothrace - the museum's "three great ladies." 
                  Allow at least 3-4 hours for a comprehensive visit.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
