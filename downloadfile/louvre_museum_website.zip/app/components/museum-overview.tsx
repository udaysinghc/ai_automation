
"use client";

import { useEffect, useState } from "react";
import { Castle, Crown, Palette, Building } from "lucide-react";

export function MuseumOverview() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById("museum-overview");
    if (element) {
      observer.observe(element);
    }

    return () => observer.disconnect();
  }, []);

  const periods = [
    {
      icon: Castle,
      title: "Medieval Fortress",
      period: "1190-1364",
      description: "King Philip II Augustus ordered the construction of a fortress on the western front of Paris's new city wall. The original structure featured thick curtain walls, ten defensive towers, and a large moat filled with water from the Seine.",
      color: "text-slate-600"
    },
    {
      icon: Crown,
      title: "Royal Residence",
      period: "1364-1682",
      description: "Transformed by Francis I during the Renaissance, the fortress became a magnificent royal palace. The king acquired masterpieces from Italy, most notably Leonardo da Vinci's Mona Lisa, establishing the foundation for future collections.",
      color: "text-primary"
    },
    {
      icon: Palette,
      title: "Public Museum",
      period: "1793-Present",
      description: "The French Revolution democratized access to cultural treasures. The Louvre opened as the Muséum Central des Arts de la République on August 10, 1793, displaying 537 paintings to the public for the first time.",
      color: "text-secondary"
    },
    {
      icon: Building,
      title: "Modern Icon",
      period: "1989-Today",
      description: "I.M. Pei's glass pyramid transformed the museum's entrance while preserving its historical grandeur. Today, the Louvre welcomes 9 million visitors annually and houses 500,000 objects across 72,735 square meters.",
      color: "text-blue-600"
    }
  ];

  return (
    <section id="museum-overview" className="py-20 classical-section parchment-texture">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6 text-secondary">A Journey Through Time</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            The Louvre's extraordinary transformation spans over 800 years, from medieval defensive fortress to the world's most-visited museum.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {periods.map((period, index) => (
            <div
              key={index}
              className={`scroll-fade-in ${isVisible ? 'visible' : ''} bg-card border border-border rounded-lg p-6 hover:shadow-xl transition-all duration-300`}
              style={{ animationDelay: `${index * 200}ms` }}
            >
              <div className="flex items-center mb-4">
                <period.icon className={`h-8 w-8 ${period.color} mr-3`} />
                <div>
                  <h3 className="text-xl font-semibold text-secondary">{period.title}</h3>
                  <p className="text-sm text-primary font-medium">{period.period}</p>
                </div>
              </div>
              <p className="text-muted-foreground leading-relaxed">{period.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
