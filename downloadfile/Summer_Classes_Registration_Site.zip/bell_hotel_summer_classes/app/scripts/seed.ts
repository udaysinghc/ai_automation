
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  // Seed classes
  const classesData = [
    {
      name: "Couples Cooking",
      slug: "couples-cooking",
      description: "Learn to create romantic meals together with expert chefs guiding you through intimate culinary experiences. From appetizers to desserts, discover the art of cooking as a couple.",
      duration: "3 hours",
      price: 2499,
      capacity: 8,
      instructor: "Chef Priya Sharma",
      schedule: "Daily at 10:00 AM, 2:00 PM, and 6:00 PM",
      image: "https://thumbs.dreamstime.com/z/young-romantic-couple-kitchen-13969864.jpg",
      features: ["Professional cooking techniques", "Romantic 3-course meal", "Recipe cards to take home", "Wine pairing suggestions", "Intimate setting for couples"]
    },
    {
      name: "Ballroom Dance",
      slug: "ballroom-dance",
      description: "Glide across the dance floor with elegant ballroom dancing lessons designed for couples to connect. Learn waltz, tango, and foxtrot in our beautiful ballroom.",
      duration: "2 hours",
      price: 1999,
      capacity: 10,
      instructor: "Master Raj & Meera",
      schedule: "Evening sessions: 5:00 PM and 7:30 PM",
      image: "https://thumbs.dreamstime.com/z/passion-elegant-couple-dancers-vintage-evening-dress-suit-dancing-retro-ballroom-dance-love-music-fashion-beauty-271607659.jpg",
      features: ["Basic ballroom techniques", "Waltz, tango, foxtrot", "Professional dance floor", "Romantic music selection", "Performance opportunity"]
    },
    {
      name: "Wine Tasting",
      slug: "wine-tasting",
      description: "Discover the art of wine appreciation with curated tastings and romantic pairings in elegant settings. Learn about wine regions, tasting techniques, and perfect pairings.",
      duration: "2.5 hours",
      price: 3499,
      capacity: 12,
      instructor: "Sommelier Arjun Kumar",
      schedule: "Afternoon sessions: 3:00 PM and 6:00 PM",
      image: "https://static3.bigstockphoto.com/7/0/2/large1500/207399865.jpg",
      features: ["Premium wine selection", "Cheese and appetizer pairings", "Tasting techniques", "Wine knowledge certificate", "Romantic candlelit setting"]
    },
    {
      name: "Art & Painting",
      slug: "art-painting",
      description: "Express your creativity together through guided painting sessions in our beautiful art studio. Create masterpieces while learning professional techniques.",
      duration: "3 hours",
      price: 1799,
      capacity: 6,
      instructor: "Artist Kavitha Reddy",
      schedule: "Morning: 9:00 AM and Afternoon: 2:00 PM",
      image: "https://i.pinimg.com/originals/cd/af/58/cdaf5893e8fa9fe8288e181776b5678d.jpg",
      features: ["Canvas and art supplies included", "Acrylic painting techniques", "Couples portrait option", "Professional art studio", "Take home your artwork"]
    },
    {
      name: "Yoga & Wellness",
      slug: "yoga-wellness",
      description: "Find inner peace and connection through couples yoga and wellness practices in serene settings. Perfect for stress relief and relationship bonding.",
      duration: "1.5 hours",
      price: 1299,
      capacity: 8,
      instructor: "Yoga Master Deepika",
      schedule: "Early morning: 6:00 AM and Evening: 7:00 PM",
      image: "https://img.freepik.com/premium-photo/serene-yoga-class-session-sunlit-wellness-center_1258-273488.jpg",
      features: ["Partner yoga poses", "Meditation session", "Breathing techniques", "Relaxation therapy", "Wellness garden setting"]
    },
    {
      name: "Floral Arrangement",
      slug: "floral-arrangement",
      description: "Create stunning floral displays and romantic bouquets while learning professional arrangement techniques. Perfect for special occasions and home decoration.",
      duration: "2 hours",
      price: 1699,
      capacity: 10,
      instructor: "Florist Sunita Patel",
      schedule: "Morning: 10:00 AM and Afternoon: 3:00 PM",
      image: "https://i.pinimg.com/originals/76/4e/dc/764edca9ba5b6c7ac4adfc9c4bb1ad25.jpg",
      features: ["Fresh flower selection", "Professional arrangement tools", "Romantic bouquet creation", "Flower care tips", "Take home arrangements"]
    }
  ]

  // Clear existing data
  await prisma.registration.deleteMany()
  await prisma.contact.deleteMany()
  await prisma.class.deleteMany()

  // Create classes
  for (const classData of classesData) {
    await prisma.class.create({
      data: classData
    })
  }

  console.log('Database seeded successfully!')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })
