
import Link from 'next/link'
import { Heart, MapPin, Phone, Mail } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-gradient-to-r from-gray-50 to-pink-50 border-t border-gray-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-pink-300 to-purple-300 rounded-full flex items-center justify-center">
                <Heart className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">Bell Hotel</h3>
                <p className="text-sm text-gray-600">Summer Classes</p>
              </div>
            </div>
            <p className="text-gray-600 mb-4">
              Experience romantic summer classes at Bell Hotel, Sivakasi. From couples cooking to ballroom dance, 
              create beautiful memories with our expertly curated programs.
            </p>
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <MapPin className="w-4 h-4" />
                <span>123 Hotel Street, Sivakasi, Tamil Nadu 626123</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Phone className="w-4 h-4" />
                <span>+91 4562 234567</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Mail className="w-4 h-4" />
                <span>classes@bellhotel.com</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-gray-600 hover:text-purple-600 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/register" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Register Now
                </Link>
              </li>
            </ul>
          </div>

          {/* Classes */}
          <div>
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Summer Classes</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/classes/couples-cooking" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Couples Cooking
                </Link>
              </li>
              <li>
                <Link href="/classes/ballroom-dance" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Ballroom Dance
                </Link>
              </li>
              <li>
                <Link href="/classes/wine-tasting" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Wine Tasting
                </Link>
              </li>
              <li>
                <Link href="/classes/art-painting" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Art & Painting
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-gray-200">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-600 text-sm">
              © {new Date().getFullYear()} Bell Hotel, Sivakasi. All rights reserved.
            </p>
            <p className="text-gray-500 text-sm mt-2 md:mt-0">
              Creating beautiful memories through romantic experiences
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
