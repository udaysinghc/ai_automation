
"use client"

import { motion } from 'framer-motion'
import { Card, CardContent } from '@/components/ui/card'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Star, Quote } from 'lucide-react'

const testimonials = [
  {
    id: 1,
    name: "Priya & Rajesh",
    location: "Chennai",
    rating: 5,
    text: "Our couples cooking class was absolutely magical! The chef was patient and funny, and we learned so much. The romantic setting at Bell Hotel made it perfect for our anniversary.",
    avatar: "PR",
    class: "Couples Cooking"
  },
  {
    id: 2,
    name: "Meera & Arun",
    location: "Madurai",
    rating: 5,
    text: "The ballroom dance lessons transformed our relationship. We went from two left feet to graceful dancers! The instructor was amazing and the hotel's ballroom is stunning.",
    avatar: "MA",
    class: "Ballroom Dance"
  },
  {
    id: 3,
    name: "Kavitha & Suresh",
    location: "Sivakasi",
    rating: 5,
    text: "Wine tasting at Bell Hotel was an incredible experience. We learned so much about wine pairing and the romantic atmosphere was perfect for our date night.",
    avatar: "KS",
    class: "Wine Tasting"
  },
  {
    id: 4,
    name: "Divya & Vikram",
    location: "Coimbatore",
    rating: 5,
    text: "The art class helped us express our creativity together. We created beautiful paintings and had so much fun. The studio environment was inspiring and peaceful.",
    avatar: "DV",
    class: "Art & Painting"
  },
  {
    id: 5,
    name: "Shruti & Kiran",
    location: "Trichy",
    rating: 5,
    text: "Yoga and wellness sessions were exactly what we needed. The peaceful environment and expert guidance helped us connect on a deeper level.",
    avatar: "SK",
    class: "Yoga & Wellness"
  },
  {
    id: 6,
    name: "Anjali & Ravi",
    location: "Salem",
    rating: 5,
    text: "The floral arrangement class was so romantic! We created beautiful bouquets and learned professional techniques. Perfect for our engagement celebration.",
    avatar: "AR",
    class: "Floral Arrangement"
  }
]

export default function TestimonialsSection() {
  return (
    <section className="py-24 bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Love Stories from Our Guests
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Hear from couples who have created beautiful memories through our romantic summer classes.
          </p>
        </motion.div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="group"
            >
              <Card className="h-full bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 group-hover:scale-105">
                <CardContent className="p-6">
                  {/* Quote Icon */}
                  <div className="flex justify-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full flex items-center justify-center">
                      <Quote className="w-6 h-6 text-white" />
                    </div>
                  </div>

                  {/* Rating */}
                  <div className="flex justify-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>

                  {/* Testimonial Text */}
                  <p className="text-gray-600 text-center mb-6 leading-relaxed">
                    "{testimonial.text}"
                  </p>

                  {/* Class Badge */}
                  <div className="flex justify-center mb-4">
                    <span className="px-3 py-1 bg-gradient-to-r from-pink-100 to-purple-100 text-purple-700 text-sm rounded-full">
                      {testimonial.class}
                    </span>
                  </div>

                  {/* Author */}
                  <div className="flex items-center justify-center space-x-3">
                    <Avatar>
                      <AvatarFallback className="bg-gradient-to-r from-pink-300 to-purple-300 text-white">
                        {testimonial.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div className="text-center">
                      <p className="font-semibold text-gray-900">{testimonial.name}</p>
                      <p className="text-sm text-gray-500">{testimonial.location}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
