
"use client"

import { motion } from 'framer-motion'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Award, Heart, MapPin, Users } from 'lucide-react'
import Image from 'next/image'

export default function AboutSection() {
  const features = [
    {
      icon: Award,
      title: "Expert Instructors",
      description: "Learn from certified professionals with years of experience in their respective fields."
    },
    {
      icon: Heart,
      title: "Romantic Atmosphere",
      description: "Every class is designed to create intimate moments and strengthen relationships."
    },
    {
      icon: MapPin,
      title: "Luxury Venue",
      description: "Experience classes in the beautiful, well-appointed facilities of Bell Hotel."
    },
    {
      icon: Users,
      title: "Small Groups",
      description: "Intimate class sizes ensure personalized attention and meaningful connections."
    }
  ]

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Badge className="bg-gradient-to-r from-pink-100 to-purple-100 text-purple-700 border-0 mb-4">
              About Bell Hotel
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Creating Magical Moments in Sivakasi
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Bell Hotel has been Sivakasi's premier destination for luxury hospitality and romantic experiences. 
              Our summer classes program combines the elegance of our world-class facilities with expert instruction 
              to create unforgettable memories for couples and individuals alike.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {features.map((feature, index) => {
                const Icon = feature.icon
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    className="flex items-start space-x-3"
                  >
                    <div className="w-10 h-10 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">{feature.title}</h3>
                      <p className="text-sm text-gray-600">{feature.description}</p>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          </motion.div>

          {/* Right Images */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="grid grid-cols-2 gap-4">
              {/* Hotel Exterior */}
              <div className="relative h-64 rounded-lg overflow-hidden">
                <Image
                  src="https://cdn.abacus.ai/images/52a52955-2873-4e4c-9793-91952ce6374b.png"
                  alt="Bell Hotel exterior view"
                  fill
                  className="object-cover"
                />
              </div>
              
              {/* Hotel Lobby */}
              <div className="relative h-64 rounded-lg overflow-hidden">
                <Image
                  src="https://cdn.abacus.ai/images/2d85170f-6f8a-438b-b4de-9defa97e1b37.png"
                  alt="Bell Hotel elegant lobby"
                  fill
                  className="object-cover"
                />
              </div>

              {/* Stats Card */}
              <div className="col-span-2">
                <Card className="bg-gradient-to-r from-pink-50 to-purple-50 border-0 shadow-lg">
                  <CardContent className="p-6">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-3xl font-bold text-purple-600 mb-2">15+</div>
                        <div className="text-sm text-gray-600">Years of Excellence</div>
                      </div>
                      <div>
                        <div className="text-3xl font-bold text-purple-600 mb-2">1000+</div>
                        <div className="text-sm text-gray-600">Happy Guests</div>
                      </div>
                      <div>
                        <div className="text-3xl font-bold text-purple-600 mb-2">50+</div>
                        <div className="text-sm text-gray-600">Luxury Suites</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Decorative Elements */}
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-r from-pink-200 to-purple-200 rounded-full opacity-20"></div>
            <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-gradient-to-r from-blue-200 to-cyan-200 rounded-full opacity-20"></div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
