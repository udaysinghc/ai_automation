
export const dynamic = "force-dynamic"

import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { 
      firstName, 
      lastName, 
      email, 
      phone, 
      classId, 
      preferredDate, 
      specialRequests, 
      guestCount 
    } = body

    // Validate required fields
    if (!firstName || !lastName || !email || !phone || !classId || !preferredDate) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Check if class exists
    const classExists = await prisma.class.findUnique({
      where: { id: classId }
    })

    if (!classExists) {
      return NextResponse.json(
        { error: 'Class not found' },
        { status: 404 }
      )
    }

    // Create registration
    const registration = await prisma.registration.create({
      data: {
        firstName,
        lastName,
        email,
        phone,
        classId,
        preferredDate: new Date(preferredDate),
        specialRequests: specialRequests || null,
        guestCount: guestCount || 1,
        status: 'pending'
      }
    })

    return NextResponse.json(
      { 
        message: 'Registration successful!', 
        registration: {
          id: registration.id,
          firstName: registration.firstName,
          lastName: registration.lastName,
          email: registration.email,
          status: registration.status
        }
      },
      { status: 201 }
    )

  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
