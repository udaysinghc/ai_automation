
"use client"

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import Header from '@/components/header'
import Footer from '@/components/footer'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Heart, Calendar, User, Mail, Phone, Users, MessageSquare, ChefHat, Music, Wine, Palette, Flower } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface ClassData {
  id: string
  name: string
  slug: string
  description: string
  duration: string
  price: number
  capacity: number
  instructor: string
  schedule: string
  image: string
  features: string[]
}

const iconMap = {
  'couples-cooking': ChefHat,
  'ballroom-dance': Music,
  'wine-tasting': Wine,
  'art-painting': Palette,
  'yoga-wellness': Heart,
  'floral-arrangement': Flower
}

export default function RegisterPage() {
  const [classes, setClasses] = useState<ClassData[]>([])
  const [selectedClass, setSelectedClass] = useState<string>('')
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    preferredDate: '',
    guestCount: '2',
    specialRequests: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    fetchClasses()
  }, [])

  const fetchClasses = async () => {
    try {
      const response = await fetch('/api/classes')
      if (response.ok) {
        const data = await response.json()
        setClasses(data)
      }
    } catch (error) {
      console.error('Error fetching classes:', error)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!selectedClass) {
      toast({
        title: "Please select a class",
        description: "You must select a class to register for.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const response = await fetch('/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          classId: selectedClass,
          guestCount: parseInt(formData.guestCount)
        }),
      })

      if (response.ok) {
        toast({
          title: "Registration Successful!",
          description: "Thank you for registering! We'll contact you soon with confirmation details.",
        })
        
        // Reset form
        setFormData({
          firstName: '',
          lastName: '',
          email: '',
          phone: '',
          preferredDate: '',
          guestCount: '2',
          specialRequests: ''
        })
        setSelectedClass('')
      } else {
        const error = await response.json()
        toast({
          title: "Registration Failed",
          description: error.error || "Something went wrong. Please try again.",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Unable to submit registration. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const selectedClassData = classes.find(c => c.id === selectedClass)

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      <Header />
      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-r from-pink-500 to-purple-500 text-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Register for Summer Classes
              </h1>
              <p className="text-xl text-white/90 max-w-2xl mx-auto">
                Join our romantic summer classes at Bell Hotel and create unforgettable memories together.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Registration Form */}
        <section className="py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Form */}
              <div className="lg:col-span-2">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8 }}
                >
                  <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
                    <CardHeader>
                      <CardTitle className="text-2xl font-bold text-gray-900 flex items-center">
                        <Heart className="w-6 h-6 mr-2 text-pink-500" />
                        Class Registration
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handleSubmit} className="space-y-6">
                        {/* Class Selection */}
                        <div>
                          <Label htmlFor="class" className="text-sm font-medium text-gray-700">
                            Select Class *
                          </Label>
                          <Select value={selectedClass} onValueChange={setSelectedClass}>
                            <SelectTrigger className="mt-1 border-gray-300 focus:border-purple-500 focus:ring-purple-500">
                              <SelectValue placeholder="Choose a class..." />
                            </SelectTrigger>
                            <SelectContent>
                              {classes.map((classItem) => {
                                const Icon = iconMap[classItem.slug as keyof typeof iconMap] || Heart
                                return (
                                  <SelectItem key={classItem.id} value={classItem.id}>
                                    <div className="flex items-center space-x-2">
                                      <Icon className="w-4 h-4" />
                                      <span>{classItem.name}</span>
                                      <Badge variant="secondary" className="ml-2">
                                        ₹{classItem.price.toLocaleString()}
                                      </Badge>
                                    </div>
                                  </SelectItem>
                                )
                              })}
                            </SelectContent>
                          </Select>
                        </div>

                        {/* Name Fields */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="firstName" className="text-sm font-medium text-gray-700">
                              First Name *
                            </Label>
                            <div className="relative mt-1">
                              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                              <Input
                                id="firstName"
                                name="firstName"
                                type="text"
                                required
                                value={formData.firstName}
                                onChange={handleInputChange}
                                className="pl-10 border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                                placeholder="Enter first name"
                              />
                            </div>
                          </div>
                          <div>
                            <Label htmlFor="lastName" className="text-sm font-medium text-gray-700">
                              Last Name *
                            </Label>
                            <div className="relative mt-1">
                              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                              <Input
                                id="lastName"
                                name="lastName"
                                type="text"
                                required
                                value={formData.lastName}
                                onChange={handleInputChange}
                                className="pl-10 border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                                placeholder="Enter last name"
                              />
                            </div>
                          </div>
                        </div>

                        {/* Email */}
                        <div>
                          <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                            Email Address *
                          </Label>
                          <div className="relative mt-1">
                            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <Input
                              id="email"
                              name="email"
                              type="email"
                              required
                              value={formData.email}
                              onChange={handleInputChange}
                              className="pl-10 border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                              placeholder="Enter email address"
                            />
                          </div>
                        </div>

                        {/* Phone */}
                        <div>
                          <Label htmlFor="phone" className="text-sm font-medium text-gray-700">
                            Phone Number *
                          </Label>
                          <div className="relative mt-1">
                            <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <Input
                              id="phone"
                              name="phone"
                              type="tel"
                              required
                              value={formData.phone}
                              onChange={handleInputChange}
                              className="pl-10 border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                              placeholder="Enter phone number"
                            />
                          </div>
                        </div>

                        {/* Preferred Date & Guest Count */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="preferredDate" className="text-sm font-medium text-gray-700">
                              Preferred Date *
                            </Label>
                            <div className="relative mt-1">
                              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                              <Input
                                id="preferredDate"
                                name="preferredDate"
                                type="date"
                                required
                                value={formData.preferredDate}
                                onChange={handleInputChange}
                                className="pl-10 border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                                min={new Date().toISOString().split('T')[0]}
                              />
                            </div>
                          </div>
                          <div>
                            <Label htmlFor="guestCount" className="text-sm font-medium text-gray-700">
                              Number of Guests
                            </Label>
                            <div className="relative mt-1">
                              <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                              <Input
                                id="guestCount"
                                name="guestCount"
                                type="number"
                                min="1"
                                max="4"
                                value={formData.guestCount}
                                onChange={handleInputChange}
                                className="pl-10 border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                              />
                            </div>
                          </div>
                        </div>

                        {/* Special Requests */}
                        <div>
                          <Label htmlFor="specialRequests" className="text-sm font-medium text-gray-700">
                            Special Requests (Optional)
                          </Label>
                          <div className="relative mt-1">
                            <MessageSquare className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                            <Textarea
                              id="specialRequests"
                              name="specialRequests"
                              rows={3}
                              value={formData.specialRequests}
                              onChange={handleInputChange}
                              className="pl-10 border-gray-300 focus:border-purple-500 focus:ring-purple-500 resize-none"
                              placeholder="Any special dietary requirements, accessibility needs, or other requests..."
                            />
                          </div>
                        </div>

                        {/* Submit Button */}
                        <Button
                          type="submit"
                          disabled={isSubmitting}
                          className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white py-3 text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
                        >
                          {isSubmitting ? (
                            <>
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                              Processing...
                            </>
                          ) : (
                            <>
                              <Heart className="w-5 h-5 mr-2" />
                              Complete Registration
                            </>
                          )}
                        </Button>
                      </form>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>

              {/* Selected Class Info */}
              <div className="lg:col-span-1">
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8 }}
                  className="sticky top-24"
                >
                  {selectedClassData ? (
                    <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
                      <CardHeader>
                        <CardTitle className="text-xl font-bold text-gray-900">
                          Selected Class
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="text-center">
                          <h3 className="font-semibold text-lg text-gray-900">
                            {selectedClassData.name}
                          </h3>
                          <p className="text-2xl font-bold text-purple-600 mt-2">
                            ₹{selectedClassData.price.toLocaleString()}
                          </p>
                          <p className="text-sm text-gray-600">per couple</p>
                        </div>
                        
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Duration:</span>
                            <span className="font-medium">{selectedClassData.duration}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Instructor:</span>
                            <span className="font-medium">{selectedClassData.instructor}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Max Capacity:</span>
                            <span className="font-medium">{selectedClassData.capacity} guests</span>
                          </div>
                        </div>
                        
                        <div className="pt-4 border-t border-gray-200">
                          <p className="text-sm text-gray-600 mb-2">Schedule:</p>
                          <p className="text-sm font-medium text-gray-900">
                            {selectedClassData.schedule}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  ) : (
                    <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
                      <CardContent className="py-8 text-center">
                        <Heart className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                        <p className="text-gray-500">
                          Select a class to see details
                        </p>
                      </CardContent>
                    </Card>
                  )}
                </motion.div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
