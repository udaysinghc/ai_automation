
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  TrendingUp,
  ListTodo,
  Target,
  Zap,
  Users
} from 'lucide-react';
import { DashboardMetrics } from '@/lib/types';

interface MetricsCardsProps {
  metrics: DashboardMetrics;
}

export function MetricsCards({ metrics }: MetricsCardsProps) {
  const cards = [
    {
      title: 'Total Tasks',
      value: metrics?.totalTasks?.toString() ?? '0',
      description: 'All high-priority tasks',
      icon: ListTodo,
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10'
    },
    {
      title: 'Overdue Tasks',
      value: metrics?.overdueTasks?.toString() ?? '0',
      description: 'Tasks past due date',
      icon: Clock,
      color: 'text-red-400',
      bgColor: 'bg-red-400/10'
    },
    {
      title: 'Completed',
      value: metrics?.completedTasks?.toString() ?? '0',
      description: 'Tasks completed',
      icon: CheckCircle,
      color: 'text-green-400',
      bgColor: 'bg-green-400/10'
    },
    {
      title: 'Critical Issues',
      value: metrics?.criticalTasks?.toString() ?? '0',
      description: 'Urgent attention needed',
      icon: AlertTriangle,
      color: 'text-orange-400',
      bgColor: 'bg-orange-400/10'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, index) => (
        <Card key={index} className="chart-container hover:shadow-lg transition-shadow duration-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {card.title}
            </CardTitle>
            <div className={`p-2 rounded-lg ${card.bgColor}`}>
              <card.icon className={`h-5 w-5 ${card.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{card.value}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {card.description}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
