
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { ChartData } from '@/lib/types';

interface PriorityBreakdownChartProps {
  data: ChartData['priorityBreakdown'];
}

export function PriorityBreakdownChart({ data }: PriorityBreakdownChartProps) {
  const chartData = data ?? [];

  return (
    <Card className="chart-container">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Priority Breakdown</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
            <XAxis 
              dataKey="priority" 
              tickLine={false}
              tick={{ fontSize: 10 }}
              label={{ 
                value: 'Priority Level', 
                position: 'insideBottom', 
                offset: -15, 
                style: { textAnchor: 'middle', fontSize: 11 } 
              }}
            />
            <YAxis 
              tickLine={false}
              tick={{ fontSize: 10 }}
              label={{ 
                value: 'Count', 
                angle: -90, 
                position: 'insideLeft', 
                style: { textAnchor: 'middle', fontSize: 11 } 
              }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '6px',
                fontSize: '11px'
              }}
            />
            <Bar dataKey="count" fill="#60B5FF" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
