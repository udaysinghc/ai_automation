
import { Sidebar } from '@/components/sidebar';
import { Header } from '@/components/header';
import { MetricsCards } from '@/components/metrics-cards';
import { StatusDistributionChart } from '@/components/charts/status-distribution-chart';
import { PriorityBreakdownChart } from '@/components/charts/priority-breakdown-chart';
import { AssigneeWorkloadChart } from '@/components/charts/assignee-workload-chart';
import { TaskProgressChart } from '@/components/charts/task-progress-chart';
import { TaskList } from '@/components/task-list';
import { mockMetrics, mockChartData, getHighPriorityTasks } from '@/lib/mock-data';

export default function Dashboard() {
  const highPriorityTasks = getHighPriorityTasks();

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      
      <div className="pl-0 md:pl-64">
        <Header />
        
        <main className="p-6 space-y-8">
          {/* Metrics Cards */}
          <section id="overview">
            <MetricsCards metrics={mockMetrics} />
          </section>

          {/* Charts Grid */}
          <section id="analytics" className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <StatusDistributionChart data={mockChartData.statusDistribution} />
            <PriorityBreakdownChart data={mockChartData.priorityBreakdown} />
            <AssigneeWorkloadChart data={mockChartData.assigneeWorkload} />
            <TaskProgressChart data={mockChartData.taskProgress} />
          </section>

          {/* Task List */}
          <section id="tasks">
            <TaskList tasks={highPriorityTasks} />
          </section>
        </main>
      </div>
    </div>
  );
}
