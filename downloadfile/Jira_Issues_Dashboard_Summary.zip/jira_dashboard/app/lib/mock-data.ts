
import { JiraTask, DashboardMetrics, ChartData, User } from './types';

export const mockUsers: User[] = [
  { id: '1', name: 'John Doe', email: 'john@company.com', role: 'Senior Developer' },
  { id: '2', name: 'Sarah Smith', email: 'sarah@company.com', role: 'Product Manager' },
  { id: '3', name: 'Mike Johnson', email: 'mike@company.com', role: 'QA Engineer' },
  { id: '4', name: 'Emily Davis', email: 'emily@company.com', role: 'UI/UX Designer' },
  { id: '5', name: 'David Wilson', email: 'david@company.com', role: 'DevOps Engineer' },
  { id: '6', name: 'Lisa Brown', email: 'lisa@company.com', role: 'Backend Developer' },
];

export const mockTasks: JiraTask[] = [
  {
    id: '1',
    key: 'PROJ-101',
    summary: 'Critical authentication bug causing user lockouts',
    description: 'Users are unable to login after failed attempts, session management issue',
    priority: 'Critical',
    status: 'In Progress',
    assignee: mockUsers[0],
    reporter: mockUsers[1],
    taskType: 'Bug',
    created: '2025-01-10T09:00:00Z',
    updated: '2025-01-15T14:30:00Z',
    dueDate: '2025-01-18T17:00:00Z',
    estimatedHours: 8,
    timeSpent: 5,
    storyPoints: 5,
    labels: ['authentication', 'security', 'urgent'],
    project: { id: 'proj1', name: 'Core Platform', key: 'PROJ' }
  },
  {
    id: '2',
    key: 'PROJ-102',
    summary: 'Implement new dashboard analytics feature',
    description: 'Create comprehensive analytics dashboard with real-time metrics',
    priority: 'High',
    status: 'Code Review',
    assignee: mockUsers[1],
    reporter: mockUsers[2],
    taskType: 'Story',
    created: '2025-01-08T10:00:00Z',
    updated: '2025-01-15T16:00:00Z',
    dueDate: '2025-01-20T17:00:00Z',
    estimatedHours: 16,
    timeSpent: 12,
    storyPoints: 8,
    labels: ['analytics', 'dashboard', 'feature'],
    project: { id: 'proj1', name: 'Core Platform', key: 'PROJ' }
  },
  {
    id: '3',
    key: 'PROJ-103',
    summary: 'Database performance optimization',
    description: 'Optimize slow queries and improve database indexing',
    priority: 'High',
    status: 'Testing',
    assignee: mockUsers[2],
    reporter: mockUsers[0],
    taskType: 'Task',
    created: '2025-01-05T11:00:00Z',
    updated: '2025-01-14T13:00:00Z',
    dueDate: '2025-01-19T17:00:00Z',
    estimatedHours: 12,
    timeSpent: 10,
    storyPoints: 5,
    labels: ['database', 'performance', 'optimization'],
    project: { id: 'proj1', name: 'Core Platform', key: 'PROJ' }
  },
  {
    id: '4',
    key: 'PROJ-104',
    summary: 'Mobile app responsive design fixes',
    description: 'Fix layout issues on mobile devices and improve UX',
    priority: 'Medium',
    status: 'In Progress',
    assignee: mockUsers[3],
    reporter: mockUsers[1],
    taskType: 'Bug',
    created: '2025-01-12T08:00:00Z',
    updated: '2025-01-15T12:00:00Z',
    dueDate: '2025-01-22T17:00:00Z',
    estimatedHours: 6,
    timeSpent: 3,
    storyPoints: 3,
    labels: ['mobile', 'responsive', 'ui'],
    project: { id: 'proj1', name: 'Core Platform', key: 'PROJ' }
  },
  {
    id: '5',
    key: 'PROJ-105',
    summary: 'API rate limiting implementation',
    description: 'Implement rate limiting to prevent API abuse',
    priority: 'High',
    status: 'To Do',
    assignee: mockUsers[4],
    reporter: mockUsers[0],
    taskType: 'Story',
    created: '2025-01-13T09:30:00Z',
    updated: '2025-01-15T09:30:00Z',
    dueDate: '2025-01-25T17:00:00Z',
    estimatedHours: 10,
    timeSpent: 0,
    storyPoints: 5,
    labels: ['api', 'security', 'rate-limiting'],
    project: { id: 'proj1', name: 'Core Platform', key: 'PROJ' }
  },
  {
    id: '6',
    key: 'PROJ-106',
    summary: 'User notification system enhancement',
    description: 'Improve email and push notification delivery system',
    priority: 'Medium',
    status: 'Done',
    assignee: mockUsers[5],
    reporter: mockUsers[1],
    taskType: 'Epic',
    created: '2025-01-01T10:00:00Z',
    updated: '2025-01-14T15:00:00Z',
    dueDate: '2025-01-15T17:00:00Z',
    estimatedHours: 20,
    timeSpent: 18,
    storyPoints: 13,
    labels: ['notifications', 'email', 'push'],
    project: { id: 'proj1', name: 'Core Platform', key: 'PROJ' }
  },
  {
    id: '7',
    key: 'PROJ-107',
    summary: 'Critical security vulnerability patch',
    description: 'Address SQL injection vulnerability in user search',
    priority: 'Critical',
    status: 'Code Review',
    assignee: mockUsers[0],
    reporter: mockUsers[4],
    taskType: 'Bug',
    created: '2025-01-14T15:00:00Z',
    updated: '2025-01-15T17:00:00Z',
    dueDate: '2025-01-16T17:00:00Z',
    estimatedHours: 4,
    timeSpent: 3,
    storyPoints: 3,
    labels: ['security', 'vulnerability', 'sql'],
    project: { id: 'proj1', name: 'Core Platform', key: 'PROJ' }
  },
  {
    id: '8',
    key: 'PROJ-108',
    summary: 'Load testing for production deployment',
    description: 'Conduct comprehensive load testing before major release',
    priority: 'High',
    status: 'In Progress',
    assignee: mockUsers[2],
    reporter: mockUsers[1],
    taskType: 'Task',
    created: '2025-01-11T11:00:00Z',
    updated: '2025-01-15T10:00:00Z',
    dueDate: '2025-01-21T17:00:00Z',
    estimatedHours: 14,
    timeSpent: 8,
    storyPoints: 8,
    labels: ['testing', 'load', 'performance'],
    project: { id: 'proj1', name: 'Core Platform', key: 'PROJ' }
  }
];

export const mockMetrics: DashboardMetrics = {
  totalTasks: mockTasks.length,
  overdueTasks: mockTasks.filter(task => {
    const dueDate = task.dueDate ? new Date(task.dueDate) : null;
    return dueDate && dueDate < new Date() && task.status !== 'Done';
  }).length,
  completedTasks: mockTasks.filter(task => task.status === 'Done').length,
  criticalTasks: mockTasks.filter(task => task.priority === 'Critical').length,
  highPriorityTasks: mockTasks.filter(task => task.priority === 'High').length,
  averageCompletionTime: 5.2,
  teamVelocity: 42
};

export const mockChartData: ChartData = {
  statusDistribution: [
    { name: 'To Do', value: 1, color: '#60B5FF' },
    { name: 'In Progress', value: 3, color: '#FF9149' },
    { name: 'Code Review', value: 2, color: '#FF9898' },
    { name: 'Testing', value: 1, color: '#FF90BB' },
    { name: 'Done', value: 1, color: '#80D8C3' }
  ],
  priorityBreakdown: [
    { priority: 'Critical', count: 2, color: '#FF6363' },
    { priority: 'High', count: 3, color: '#FF9149' },
    { priority: 'Medium', count: 2, color: '#FF9898' },
    { priority: 'Low', count: 1, color: '#80D8C3' }
  ],
  assigneeWorkload: [
    { assignee: 'John Doe', tasks: 2, completed: 0, inProgress: 2 },
    { assignee: 'Sarah Smith', tasks: 1, completed: 0, inProgress: 1 },
    { assignee: 'Mike Johnson', tasks: 2, completed: 0, inProgress: 2 },
    { assignee: 'Emily Davis', tasks: 1, completed: 0, inProgress: 1 },
    { assignee: 'David Wilson', tasks: 1, completed: 0, inProgress: 1 },
    { assignee: 'Lisa Brown', tasks: 1, completed: 1, inProgress: 0 }
  ],
  taskProgress: [
    { date: '2025-01-01', created: 1, completed: 0, resolved: 0 },
    { date: '2025-01-05', created: 1, completed: 0, resolved: 0 },
    { date: '2025-01-08', created: 1, completed: 0, resolved: 0 },
    { date: '2025-01-10', created: 1, completed: 0, resolved: 0 },
    { date: '2025-01-11', created: 1, completed: 0, resolved: 0 },
    { date: '2025-01-12', created: 1, completed: 0, resolved: 0 },
    { date: '2025-01-13', created: 1, completed: 0, resolved: 0 },
    { date: '2025-01-14', created: 1, completed: 1, resolved: 1 },
    { date: '2025-01-15', created: 0, completed: 0, resolved: 0 }
  ]
};

export const getHighPriorityTasks = (): JiraTask[] => {
  return mockTasks.filter(task => task.priority === 'Critical' || task.priority === 'High');
};

export const getTasksByStatus = (status: string): JiraTask[] => {
  return mockTasks.filter(task => task.status === status);
};

export const getTasksByAssignee = (assigneeId: string): JiraTask[] => {
  return mockTasks.filter(task => task.assignee.id === assigneeId);
};

export const getOverdueTasks = (): JiraTask[] => {
  return mockTasks.filter(task => {
    const dueDate = task.dueDate ? new Date(task.dueDate) : null;
    return dueDate && dueDate < new Date() && task.status !== 'Done';
  });
};
