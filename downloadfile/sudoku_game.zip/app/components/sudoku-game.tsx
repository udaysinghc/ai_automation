
"use client";

import { useState, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle, RotateCcw } from "lucide-react";
import { validateSudoku, isValidMove, generateNewPuzzle } from "@/lib/sudoku-utils";

type CellValue = number | null;
type SudokuGrid = CellValue[][];

export default function SudokuGame() {
  const [grid, setGrid] = useState<SudokuGrid>([]);
  const [initialGrid, setInitialGrid] = useState<SudokuGrid>([]);
  const [selectedCell, setSelectedCell] = useState<{ row: number; col: number } | null>(null);
  const [gameStatus, setGameStatus] = useState<'playing' | 'solved' | 'error' | null>(null);
  const [errors, setErrors] = useState<Set<string>>(new Set());

  // Initialize the grid after component mounts to prevent hydration errors
  useEffect(() => {
    const newPuzzle = generateNewPuzzle();
    setGrid(newPuzzle);
    setInitialGrid(newPuzzle);
  }, []);

  const handleCellClick = useCallback((row: number, col: number) => {
    // Don't allow clicking on pre-filled cells
    if (initialGrid?.[row]?.[col] !== null) {
      return;
    }
    setSelectedCell({ row, col });
  }, [initialGrid]);

  const handleKeyPress = useCallback((event: KeyboardEvent) => {
    if (!selectedCell) return;

    const { row, col } = selectedCell;
    const key = event.key;

    // Only allow numbers 1-9 and backspace/delete
    if (key >= '1' && key <= '9') {
      const value = parseInt(key);
      const newGrid = grid?.map(r => [...r]) ?? [];
      
      if (newGrid?.[row]) {
        newGrid[row][col] = value;
        setGrid(newGrid);
        
        // Check if this move creates any conflicts
        const newErrors = new Set<string>();
        if (!isValidMove(newGrid, row, col, value)) {
          newErrors.add(`${row}-${col}`);
        }
        setErrors(newErrors);
        setGameStatus(null);
      }
    } else if (key === 'Backspace' || key === 'Delete') {
      const newGrid = grid?.map(r => [...r]) ?? [];
      if (newGrid?.[row]) {
        newGrid[row][col] = null;
        setGrid(newGrid);
        setErrors(new Set());
        setGameStatus(null);
      }
    }
  }, [selectedCell, grid]);

  // Add keyboard event listener
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => handleKeyPress(event);
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyPress]);

  const handleNumberClick = useCallback((number: number) => {
    if (!selectedCell) return;

    const { row, col } = selectedCell;
    const newGrid = grid?.map(r => [...r]) ?? [];
    
    if (newGrid?.[row]) {
      newGrid[row][col] = number;
      setGrid(newGrid);
      
      // Check if this move creates any conflicts
      const newErrors = new Set<string>();
      if (!isValidMove(newGrid, row, col, number)) {
        newErrors.add(`${row}-${col}`);
      }
      setErrors(newErrors);
      setGameStatus(null);
    }
  }, [selectedCell, grid]);

  const handleClear = useCallback(() => {
    if (!selectedCell) return;

    const { row, col } = selectedCell;
    const newGrid = grid?.map(r => [...r]) ?? [];
    
    if (newGrid?.[row]) {
      newGrid[row][col] = null;
      setGrid(newGrid);
      setErrors(new Set());
      setGameStatus(null);
    }
  }, [selectedCell, grid]);

  const checkSolution = useCallback(() => {
    if (!grid) return;

    const result = validateSudoku(grid);
    setGameStatus(result ? 'solved' : 'error');
    
    if (!result) {
      // Find and highlight errors
      const newErrors = new Set<string>();
      for (let row = 0; row < 9; row++) {
        for (let col = 0; col < 9; col++) {
          const value = grid?.[row]?.[col];
          if (value && !isValidMove(grid, row, col, value)) {
            newErrors.add(`${row}-${col}`);
          }
        }
      }
      setErrors(newErrors);
    } else {
      setErrors(new Set());
    }
  }, [grid]);

  const startNewGame = useCallback(() => {
    const newPuzzle = generateNewPuzzle();
    setGrid(newPuzzle);
    setInitialGrid(newPuzzle);
    setSelectedCell(null);
    setGameStatus(null);
    setErrors(new Set());
  }, []);

  const renderCell = (row: number, col: number) => {
    const value = grid?.[row]?.[col];
    const isInitial = initialGrid?.[row]?.[col] !== null;
    const isSelected = selectedCell?.row === row && selectedCell?.col === col;
    const hasError = errors.has(`${row}-${col}`);

    let cellClasses = "sudoku-cell";
    if (isInitial) cellClasses += " prefilled";
    if (isSelected) cellClasses += " selected";
    if (hasError) cellClasses += " error";

    return (
      <div
        key={`${row}-${col}`}
        className={cellClasses}
        onClick={() => handleCellClick(row, col)}
      >
        {value ? value.toString() : ""}
      </div>
    );
  };

  // Show loading state while grid is being initialized
  if (grid.length === 0) {
    return (
      <div className="flex flex-col items-center space-y-6">
        <div className="sudoku-grid">
          {Array.from({ length: 81 }, (_, index) => (
            <div key={index} className="sudoku-cell"></div>
          ))}
        </div>
        <div className="text-center text-gray-500">Loading puzzle...</div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center space-y-6">
      {/* Game Grid */}
      <div className="sudoku-grid">
        {Array.from({ length: 9 }, (_, row) =>
          Array.from({ length: 9 }, (_, col) => renderCell(row, col))
        )}
      </div>

      {/* Number Input Buttons */}
      <div className="flex flex-wrap gap-2 justify-center">
        {Array.from({ length: 9 }, (_, i) => (
          <Button
            key={i + 1}
            variant="outline"
            size="sm"
            onClick={() => handleNumberClick(i + 1)}
            className="w-10 h-10"
            disabled={!selectedCell || initialGrid?.[selectedCell.row]?.[selectedCell.col] !== null}
          >
            {i + 1}
          </Button>
        ))}
        <Button
          variant="outline"
          size="sm"
          onClick={handleClear}
          className="px-4 h-10"
          disabled={!selectedCell || initialGrid?.[selectedCell.row]?.[selectedCell.col] !== null}
        >
          Clear
        </Button>
      </div>

      {/* Game Controls */}
      <div className="flex gap-4">
        <Button onClick={checkSolution} className="flex items-center gap-2">
          <CheckCircle className="w-4 h-4" />
          Check Solution
        </Button>
        <Button onClick={startNewGame} variant="outline" className="flex items-center gap-2">
          <RotateCcw className="w-4 h-4" />
          New Game
        </Button>
      </div>

      {/* Game Status */}
      {gameStatus === 'solved' && (
        <div className="flex items-center gap-2 text-green-600 font-semibold">
          <CheckCircle className="w-5 h-5" />
          Congratulations! You solved the puzzle!
        </div>
      )}
      {gameStatus === 'error' && (
        <div className="flex items-center gap-2 text-red-600 font-semibold">
          <XCircle className="w-5 h-5" />
          There are errors in your solution. Check the highlighted cells.
        </div>
      )}

      {/* Instructions */}
      <div className="text-center text-sm text-gray-600 max-w-lg">
        <p>Click on a cell and use the number buttons or keyboard to enter values.</p>
        <p>Each row, column, and 3×3 box must contain all numbers from 1 to 9.</p>
      </div>
    </div>
  );
}
