
"use client"

import { useState } from 'react'
import Link from 'next/link'
import { Menu, X, Heart, Phone, MapPin } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { motion } from 'framer-motion'

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md shadow-sm">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-pink-300 to-purple-300 rounded-full flex items-center justify-center">
              <Heart className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Bell Hotel</h1>
              <p className="text-xs text-gray-500">Summer Classes</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-purple-600 transition-colors">
              Home
            </Link>
            <div className="relative group">
              <button className="text-gray-700 hover:text-purple-600 transition-colors">
                Classes
              </button>
              <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
                <div className="p-4 space-y-2">
                  <Link href="/classes/couples-cooking" className="block px-4 py-2 text-sm text-gray-700 hover:bg-pink-50 hover:text-pink-600 rounded-md transition-colors">
                    Couples Cooking
                  </Link>
                  <Link href="/classes/ballroom-dance" className="block px-4 py-2 text-sm text-gray-700 hover:bg-pink-50 hover:text-pink-600 rounded-md transition-colors">
                    Ballroom Dance
                  </Link>
                  <Link href="/classes/wine-tasting" className="block px-4 py-2 text-sm text-gray-700 hover:bg-pink-50 hover:text-pink-600 rounded-md transition-colors">
                    Wine Tasting
                  </Link>
                  <Link href="/classes/art-painting" className="block px-4 py-2 text-sm text-gray-700 hover:bg-pink-50 hover:text-pink-600 rounded-md transition-colors">
                    Art & Painting
                  </Link>
                  <Link href="/classes/yoga-wellness" className="block px-4 py-2 text-sm text-gray-700 hover:bg-pink-50 hover:text-pink-600 rounded-md transition-colors">
                    Yoga & Wellness
                  </Link>
                  <Link href="/classes/floral-arrangement" className="block px-4 py-2 text-sm text-gray-700 hover:bg-pink-50 hover:text-pink-600 rounded-md transition-colors">
                    Floral Arrangement
                  </Link>
                </div>
              </div>
            </div>
            <Link href="/about" className="text-gray-700 hover:text-purple-600 transition-colors">
              About
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-purple-600 transition-colors">
              Contact
            </Link>
          </nav>

          {/* Contact Info & CTA */}
          <div className="hidden lg:flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <Phone className="w-4 h-4" />
              <span>+91 4562 234567</span>
            </div>
            <Link href="/register">
              <Button className="bg-gradient-to-r from-pink-400 to-purple-400 hover:from-pink-500 hover:to-purple-500 text-white px-6 py-2 rounded-full transition-all duration-300">
                Register Now
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="md:hidden p-2 rounded-md text-gray-700 hover:text-purple-600 hover:bg-gray-100 transition-colors"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden bg-white border-t border-gray-200"
          >
            <div className="px-4 py-4 space-y-4">
              <Link href="/" className="block text-gray-700 hover:text-purple-600 transition-colors">
                Home
              </Link>
              <div className="space-y-2">
                <p className="font-medium text-gray-900">Classes</p>
                <div className="pl-4 space-y-2">
                  <Link href="/classes/couples-cooking" className="block text-sm text-gray-600 hover:text-pink-600 transition-colors">
                    Couples Cooking
                  </Link>
                  <Link href="/classes/ballroom-dance" className="block text-sm text-gray-600 hover:text-pink-600 transition-colors">
                    Ballroom Dance
                  </Link>
                  <Link href="/classes/wine-tasting" className="block text-sm text-gray-600 hover:text-pink-600 transition-colors">
                    Wine Tasting
                  </Link>
                  <Link href="/classes/art-painting" className="block text-sm text-gray-600 hover:text-pink-600 transition-colors">
                    Art & Painting
                  </Link>
                  <Link href="/classes/yoga-wellness" className="block text-sm text-gray-600 hover:text-pink-600 transition-colors">
                    Yoga & Wellness
                  </Link>
                  <Link href="/classes/floral-arrangement" className="block text-sm text-gray-600 hover:text-pink-600 transition-colors">
                    Floral Arrangement
                  </Link>
                </div>
              </div>
              <Link href="/about" className="block text-gray-700 hover:text-purple-600 transition-colors">
                About
              </Link>
              <Link href="/contact" className="block text-gray-700 hover:text-purple-600 transition-colors">
                Contact
              </Link>
              <div className="pt-4 border-t border-gray-200">
                <div className="flex items-center space-x-2 text-sm text-gray-600 mb-4">
                  <Phone className="w-4 h-4" />
                  <span>+91 4562 234567</span>
                </div>
                <Link href="/register">
                  <Button className="w-full bg-gradient-to-r from-pink-400 to-purple-400 hover:from-pink-500 hover:to-purple-500 text-white">
                    Register Now
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </header>
  )
}
