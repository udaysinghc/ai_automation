
"use client"

import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Heart, ArrowRight, Gift } from 'lucide-react'
import Link from 'next/link'

export default function CTASection() {
  return (
    <section className="py-24 bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-white/5"></div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          {/* Icon */}
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center">
              <Gift className="w-8 h-8 text-white" />
            </div>
          </div>

          {/* Heading */}
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Start Your Romantic Journey Today
          </h2>

          {/* Subheading */}
          <p className="text-xl text-white/90 max-w-3xl mx-auto mb-8 leading-relaxed">
            Join hundreds of couples who have discovered new passions and strengthened their bonds through our 
            expertly curated summer classes at Bell Hotel, Sivakasi.
          </p>

          {/* Features */}
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-8 mb-10">
            <div className="flex items-center space-x-2 text-white/90">
              <Heart className="w-5 h-5" />
              <span>Romantic Atmosphere</span>
            </div>
            <div className="flex items-center space-x-2 text-white/90">
              <Gift className="w-5 h-5" />
              <span>Expert Instruction</span>
            </div>
            <div className="flex items-center space-x-2 text-white/90">
              <ArrowRight className="w-5 h-5" />
              <span>Luxury Setting</span>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link href="/register">
              <Button 
                size="lg" 
                className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-4 rounded-full text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <Heart className="w-5 h-5 mr-2" />
                Register Now
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Link href="/contact">
              <Button 
                variant="outline" 
                size="lg" 
                className="border-white text-white hover:bg-white hover:text-purple-600 px-8 py-4 rounded-full text-lg font-semibold backdrop-blur-md bg-white/10"
              >
                Get More Info
              </Button>
            </Link>
          </div>

          {/* Special Offer */}
          <div className="mt-8 p-4 bg-white/10 backdrop-blur-md rounded-lg border border-white/20 max-w-md mx-auto">
            <p className="text-white/90 text-sm">
              <strong>Limited Time:</strong> Book any 2 classes and get 20% off your total!
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
