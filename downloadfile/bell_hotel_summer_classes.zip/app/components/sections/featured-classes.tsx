
"use client"

import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ChefHat, Music, Wine, Palette, Heart, Flower } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'

const classes = [
  {
    id: 1,
    title: "Couples Cooking",
    description: "Learn to create romantic meals together with expert chefs guiding you through intimate culinary experiences.",
    image: "https://thumbs.dreamstime.com/z/young-romantic-couple-kitchen-13969864.jpg",
    price: "₹2,499",
    duration: "3 hours",
    level: "Beginner",
    icon: ChefHat,
    slug: "couples-cooking",
    gradient: "from-pink-400 to-rose-400"
  },
  {
    id: 2,
    title: "Ballroom Dance",
    description: "Glide across the dance floor with elegant ballroom dancing lessons designed for couples to connect.",
    image: "https://thumbs.dreamstime.com/z/passion-elegant-couple-dancers-vintage-evening-dress-suit-dancing-retro-ballroom-dance-love-music-fashion-beauty-271607659.jpg",
    price: "₹1,999",
    duration: "2 hours",
    level: "All Levels",
    icon: Music,
    slug: "ballroom-dance",
    gradient: "from-purple-400 to-indigo-400"
  },
  {
    id: 3,
    title: "Wine Tasting",
    description: "Discover the art of wine appreciation with curated tastings and romantic pairings in elegant settings.",
    image: "https://static3.bigstockphoto.com/7/0/2/large1500/207399865.jpg",
    price: "₹3,499",
    duration: "2.5 hours",
    level: "Intermediate",
    icon: Wine,
    slug: "wine-tasting",
    gradient: "from-purple-400 to-pink-400"
  },
  {
    id: 4,
    title: "Art & Painting",
    description: "Express your creativity together through guided painting sessions in our beautiful art studio.",
    image: "https://i.pinimg.com/originals/cd/af/58/cdaf5893e8fa9fe8288e181776b5678d.jpg",
    price: "₹1,799",
    duration: "3 hours",
    level: "Beginner",
    icon: Palette,
    slug: "art-painting",
    gradient: "from-blue-400 to-cyan-400"
  },
  {
    id: 5,
    title: "Yoga & Wellness",
    description: "Find inner peace and connection through couples yoga and wellness practices in serene settings.",
    image: "https://img.freepik.com/premium-photo/serene-yoga-class-session-sunlit-wellness-center_1258-273488.jpg",
    price: "₹1,299",
    duration: "1.5 hours",
    level: "All Levels",
    icon: Heart,
    slug: "yoga-wellness",
    gradient: "from-green-400 to-emerald-400"
  },
  {
    id: 6,
    title: "Floral Arrangement",
    description: "Create stunning floral displays and romantic bouquets while learning professional arrangement techniques.",
    image: "https://i.pinimg.com/originals/76/4e/dc/764edca9ba5b6c7ac4adfc9c4bb1ad25.jpg",
    price: "₹1,699",
    duration: "2 hours",
    level: "Beginner",
    icon: Flower,
    slug: "floral-arrangement",
    gradient: "from-pink-400 to-purple-400"
  }
]

export default function FeaturedClasses() {
  return (
    <section className="py-24 bg-gradient-to-br from-pink-50 via-purple-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Our Summer Classes
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover romantic experiences designed to bring couples closer together while learning new skills in luxury settings.
          </p>
        </motion.div>

        {/* Classes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {classes.map((classItem, index) => {
            const Icon = classItem.icon
            return (
              <motion.div
                key={classItem.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                className="group"
              >
                <Card className="h-full overflow-hidden bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-2xl transition-all duration-300 group-hover:scale-105">
                  {/* Image */}
                  <div className="relative h-48 overflow-hidden">
                    <Image
                      src={classItem.image}
                      alt={classItem.title}
                      fill
                      className="object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                    <div className="absolute top-4 right-4">
                      <Badge className={`bg-gradient-to-r ${classItem.gradient} text-white border-0`}>
                        {classItem.level}
                      </Badge>
                    </div>
                    <div className="absolute bottom-4 left-4">
                      <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${classItem.gradient} flex items-center justify-center`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  </div>

                  <CardHeader className="pb-3">
                    <CardTitle className="text-xl font-bold text-gray-900 group-hover:text-purple-600 transition-colors">
                      {classItem.title}
                    </CardTitle>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {classItem.description}
                    </p>
                  </CardHeader>

                  <CardContent className="pt-0">
                    <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                      <span>{classItem.duration}</span>
                      <span className="text-2xl font-bold text-purple-600">{classItem.price}</span>
                    </div>
                  </CardContent>

                  <CardFooter className="pt-0">
                    <Link href={`/classes/${classItem.slug}`} className="w-full">
                      <Button className={`w-full bg-gradient-to-r ${classItem.gradient} hover:opacity-90 text-white border-0 shadow-md hover:shadow-lg transition-all duration-300`}>
                        Learn More
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </motion.div>
            )
          })}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mt-16"
        >
          <Link href="/register">
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white px-8 py-4 rounded-full text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
            >
              Register for All Classes
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  )
}
