
"use client"

import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Calendar, Clock, Users, Star, ChefHat, Music, Wine, Palette, Heart, Flower } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'
import RegistrationForm from '@/components/registration-form'
import { useState } from 'react'

interface ClassData {
  id: string
  name: string
  slug: string
  description: string
  duration: string
  price: number
  capacity: number
  instructor: string
  schedule: string
  image: string
  features: string[]
}

const iconMap = {
  'couples-cooking': ChefHat,
  'ballroom-dance': Music,
  'wine-tasting': Wine,
  'art-painting': Palette,
  'yoga-wellness': Heart,
  'floral-arrangement': Flower
}

export default function ClassDetail({ classData }: { classData: ClassData }) {
  const [showRegistration, setShowRegistration] = useState(false)
  const Icon = iconMap[classData.slug as keyof typeof iconMap] || Heart

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative h-96 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src={classData.image}
            alt={classData.name}
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30"></div>
        </div>
        
        <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-white"
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full flex items-center justify-center">
                <Icon className="w-6 h-6 text-white" />
              </div>
              <Badge className="bg-white/20 text-white border-0">
                {classData.duration}
              </Badge>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">{classData.name}</h1>
            <p className="text-xl text-white/90 mb-6 max-w-2xl">
              {classData.description}
            </p>
            <div className="flex items-center space-x-6 text-white/80">
              <div className="flex items-center space-x-2">
                <Users className="w-5 h-5" />
                <span>Max {classData.capacity} guests</span>
              </div>
              <div className="flex items-center space-x-2">
                <Star className="w-5 h-5" />
                <span>Expert Instructor</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 bg-gradient-to-br from-pink-50 to-purple-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Left Column - Details */}
            <div className="lg:col-span-2 space-y-8">
              {/* Class Information */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-2xl font-bold text-gray-900">
                      Class Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="flex items-center space-x-3">
                        <Clock className="w-5 h-5 text-purple-600" />
                        <div>
                          <p className="font-semibold text-gray-900">Duration</p>
                          <p className="text-gray-600">{classData.duration}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Users className="w-5 h-5 text-purple-600" />
                        <div>
                          <p className="font-semibold text-gray-900">Capacity</p>
                          <p className="text-gray-600">Max {classData.capacity} guests</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Star className="w-5 h-5 text-purple-600" />
                        <div>
                          <p className="font-semibold text-gray-900">Instructor</p>
                          <p className="text-gray-600">{classData.instructor}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Calendar className="w-5 h-5 text-purple-600" />
                        <div>
                          <p className="font-semibold text-gray-900">Schedule</p>
                          <p className="text-gray-600">{classData.schedule}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Features */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-2xl font-bold text-gray-900">
                      What's Included
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {classData.features.map((feature, index) => (
                        <div key={index} className="flex items-center space-x-3">
                          <div className="w-6 h-6 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full flex items-center justify-center flex-shrink-0">
                            <Heart className="w-3 h-3 text-white" />
                          </div>
                          <p className="text-gray-700">{feature}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            {/* Right Column - Booking */}
            <div className="lg:col-span-1">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="sticky top-24"
              >
                <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
                  <CardHeader className="text-center">
                    <div className="text-3xl font-bold text-purple-600 mb-2">
                      ₹{classData.price.toLocaleString()}
                    </div>
                    <p className="text-gray-600">per couple</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {!showRegistration ? (
                      <div className="space-y-4">
                        <Button 
                          onClick={() => setShowRegistration(true)}
                          className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white py-3 text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
                        >
                          <Heart className="w-5 h-5 mr-2" />
                          Book This Class
                        </Button>
                        <div className="text-center">
                          <Link href="/contact" className="text-purple-600 hover:text-purple-700 text-sm">
                            Have questions? Contact us
                          </Link>
                        </div>
                      </div>
                    ) : (
                      <RegistrationForm 
                        classId={classData.id}
                        className={classData.name}
                        onCancel={() => setShowRegistration(false)}
                      />
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
