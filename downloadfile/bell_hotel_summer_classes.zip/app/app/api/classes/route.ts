
export const dynamic = "force-dynamic"

import { NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET() {
  try {
    const classes = await prisma.class.findMany({
      orderBy: {
        createdAt: 'asc'
      }
    })

    return NextResponse.json(classes)
  } catch (error) {
    console.error('Classes fetch error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
