
"use client"

import { motion } from 'framer-motion'
import Header from '@/components/header'
import Footer from '@/components/footer'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Award, Heart, MapPin, Users, Clock, Star, Phone, Mail } from 'lucide-react'
import Image from 'next/image'

export default function AboutPage() {
  const features = [
    {
      icon: Award,
      title: "15+ Years of Excellence",
      description: "Established in 2009, Bell Hotel has been Sivakasi's premier destination for luxury hospitality and romantic experiences."
    },
    {
      icon: Heart,
      title: "Romantic Atmosphere",
      description: "Every corner of our hotel is designed to create intimate moments and strengthen relationships between couples."
    },
    {
      icon: MapPin,
      title: "Prime Location",
      description: "Located in the heart of Sivakasi, our hotel offers easy access to local attractions and cultural sites."
    },
    {
      icon: Users,
      title: "Expert Team",
      description: "Our certified instructors and hospitality professionals are dedicated to creating memorable experiences."
    },
    {
      icon: Clock,
      title: "Flexible Scheduling",
      description: "Multiple time slots throughout the day to accommodate different schedules and preferences."
    },
    {
      icon: Star,
      title: "Premium Facilities",
      description: "State-of-the-art amenities and beautifully appointed spaces for all your romantic class experiences."
    }
  ]

  const stats = [
    { number: "15+", label: "Years of Excellence" },
    { number: "1000+", label: "Happy Couples" },
    { number: "50+", label: "Luxury Suites" },
    { number: "6", label: "Summer Classes" }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      <Header />
      <main className="pt-20">
        {/* Hero Section */}
        <section className="relative py-20 bg-gradient-to-r from-pink-500 to-purple-500 text-white overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 left-0 w-full h-full bg-white/5"></div>
          </div>
          
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <Badge className="bg-white/20 text-white border-0 mb-4">
                About Bell Hotel
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                Creating Magical Moments Since 2009
              </h1>
              <p className="text-xl text-white/90 max-w-3xl mx-auto leading-relaxed">
                Bell Hotel has been Sivakasi's premier destination for luxury hospitality and romantic experiences. 
                Our summer classes program combines elegant facilities with expert instruction to create unforgettable memories.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Hotel Images */}
        <section className="py-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                className="relative h-80 rounded-lg overflow-hidden shadow-xl"
              >
                <Image
                  src="https://cdn.abacus.ai/images/52a52955-2873-4e4c-9793-91952ce6374b.png"
                  alt="Bell Hotel elegant exterior"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="text-xl font-bold">Elegant Exterior</h3>
                  <p className="text-white/90">Beautiful architecture with romantic lighting</p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                className="relative h-80 rounded-lg overflow-hidden shadow-xl"
              >
                <Image
                  src="https://cdn.abacus.ai/images/2d85170f-6f8a-438b-b4de-9defa97e1b37.png"
                  alt="Bell Hotel luxurious lobby"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="text-xl font-bold">Luxurious Lobby</h3>
                  <p className="text-white/90">Sophisticated design with romantic ambiance</p>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 bg-white">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Our Journey in Numbers
              </h2>
              <p className="text-lg text-gray-600">
                A testament to our commitment to excellence and romantic experiences
              </p>
            </motion.div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-500 mb-2">
                    {stat.number}
                  </div>
                  <div className="text-gray-600 font-medium">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 bg-gradient-to-br from-pink-50 to-purple-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Why Choose Bell Hotel?
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Experience the perfect blend of luxury, romance, and expert instruction in our beautifully appointed facilities.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => {
                const Icon = feature.icon
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: index * 0.1 }}
                    className="group"
                  >
                    <Card className="h-full bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 group-hover:scale-105">
                      <CardContent className="p-6 text-center">
                        <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full flex items-center justify-center">
                          <Icon className="w-8 h-8 text-white" />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
                        <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Contact Info */}
        <section className="py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Visit Bell Hotel, Sivakasi
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <Card className="bg-gradient-to-br from-pink-50 to-purple-50 border-0 shadow-lg">
                  <CardContent className="p-6 text-center">
                    <MapPin className="w-8 h-8 text-purple-600 mx-auto mb-4" />
                    <h3 className="font-semibold text-gray-900 mb-2">Address</h3>
                    <p className="text-gray-600">
                      123 Hotel Street<br />
                      Sivakasi, Tamil Nadu<br />
                      626123
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-pink-50 to-purple-50 border-0 shadow-lg">
                  <CardContent className="p-6 text-center">
                    <Phone className="w-8 h-8 text-purple-600 mx-auto mb-4" />
                    <h3 className="font-semibold text-gray-900 mb-2">Phone</h3>
                    <p className="text-gray-600">
                      +91 4562 234567<br />
                      +91 4562 234568
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-pink-50 to-purple-50 border-0 shadow-lg">
                  <CardContent className="p-6 text-center">
                    <Mail className="w-8 h-8 text-purple-600 mx-auto mb-4" />
                    <h3 className="font-semibold text-gray-900 mb-2">Email</h3>
                    <p className="text-gray-600">
                      classes@bellhotel.com<br />
                      info@bellhotel.com
                    </p>
                  </CardContent>
                </Card>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
