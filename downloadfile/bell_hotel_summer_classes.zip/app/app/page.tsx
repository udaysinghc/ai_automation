
import Header from '@/components/header'
import Footer from '@/components/footer'
import HeroSection from '@/components/sections/hero-section'
import FeaturedClasses from '@/components/sections/featured-classes'
import AboutSection from '@/components/sections/about-section'
import TestimonialsSection from '@/components/sections/testimonials-section'
import CTASection from '@/components/sections/cta-section'

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <FeaturedClasses />
        <AboutSection />
        <TestimonialsSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  )
}
