
import './globals.css'
import { Inter, Playfair_Display } from 'next/font/google'
import { ThemeProvider } from '@/components/theme-provider'
import { Toaster } from '@/components/ui/toaster'

const inter = Inter({ subsets: ['latin'] })
const playfair = Playfair_Display({ subsets: ['latin'], variable: '--font-playfair' })

export const metadata = {
  title: 'Bell Hotel Summer Classes - Romantic Learning Experiences in Sivakasi',
  description: 'Join romantic summer classes at Bell Hotel, Sivakasi. Couples cooking, ballroom dance, wine tasting, art workshops, yoga, and floral arrangement classes.',
  keywords: 'Bell Hotel, Sivakasi, summer classes, couples activities, romantic experiences, cooking classes, dance lessons, wine tasting',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.className} ${playfair.variable}`}>
        <ThemeProvider enableSystem={false}>
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  )
}
