
import { notFound } from 'next/navigation'
import { PrismaClient } from '@prisma/client'
import Header from '@/components/header'
import Footer from '@/components/footer'
import ClassDetail from '@/components/class-detail'

const prisma = new PrismaClient()

export async function generateStaticParams() {
  const classes = await prisma.class.findMany({
    select: { slug: true }
  })

  return classes.map((classItem) => ({
    slug: classItem.slug
  }))
}

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const classData = await prisma.class.findUnique({
    where: { slug: params.slug }
  })

  if (!classData) {
    return {
      title: 'Class Not Found - Bell Hotel Summer Classes'
    }
  }

  return {
    title: `${classData.name} - Bell Hotel Summer Classes`,
    description: classData.description
  }
}

export default async function ClassPage({ params }: { params: { slug: string } }) {
  const classData = await prisma.class.findUnique({
    where: { slug: params.slug }
  })

  if (!classData) {
    notFound()
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <ClassDetail classData={classData} />
      </main>
      <Footer />
    </div>
  )
}
